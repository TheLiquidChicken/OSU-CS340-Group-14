import React from "react";
import MaterialTypesTable from "../../Components/MaterialTypes/MaterialTypesTable";
import ColorsTable from "../../Components/Colors/ColorsTable";
import MaterialsTable from "../../Components/Materials/MaterialsTable";
import CreateMaterialsForm from "../../Components/Materials/CreateMaterialsForm";
import PartMaterialsTable from "../../Components/PartMaterials/PartMaterialsTable";
import CreatePartMaterialsForm from "../../Components/PartMachines/CreatePartMachinesForm";
import { useEffect, useState} from "react";
function MaterialTypes({backendURL, setRowToEdit}) {
    return (
        <>

            <h2>Materials Combinations</h2>
            <p>Add types of materials and color combinations here</p>
            <div class="entityCategory">
                <MaterialsTable setRowToEdit={setRowToEdit} backendURL={backendURL}/>
            </div>
        </>
    )
} export default MaterialTypes;