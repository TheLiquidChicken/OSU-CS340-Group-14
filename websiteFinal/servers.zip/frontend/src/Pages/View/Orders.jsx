import React from "react";
import OrdersTable from '/src/Components/Orders/OrdersTable';
import CreateOrderForm from "../../Components/Orders/CreateOrdersForm";
import { useEffect, useState} from "react";
function Orders({backendURL, setRowToEdit}) {
    //refreshes the component and gets data again
    const [count, setCount] = useState(0);
    const refresh = () => {
        setCount(count+1);
        loadData();
    };
    
    const [orders, setOrders] = useState([]);
    useEffect(() => {
        loadData();
    }, []
    )   
    const loadData = async () => {
        const response = await fetch(backendURL + '/orders');
        const data = await response.json();
        if(response.status === 200) {
            setOrders(data.orders);
        } else {
            const error = await response.json();
            console.error(error);
        }

    }
    return (
        <>
            <h2>3Designs Orders</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update orders here!</p>
            </div>
            <div class="entityCategory">
                <OrdersTable refresh = {refresh} orders={orders} setRowToEdit={setRowToEdit} backendURL={backendURL}/>
                <br/>
                <CreateOrderForm refresh = {refresh} backendURL={backendURL}/>
            </div>
        </>
    )
} export default Orders;