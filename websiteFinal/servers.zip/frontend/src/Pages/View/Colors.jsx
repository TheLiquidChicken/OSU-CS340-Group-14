import React from "react";
import ColorsTable from '/src/Components/Colors/ColorsTable'
import MaterialsTable from "../../Components/Materials/MaterialsTable";
import CreateMaterialsForm from "../../Components/Materials/CreateMaterialsForm";
import PartMaterialsTable from "../../Components/PartMaterials/PartMaterialsTable"
import CreatePartMaterialsForm from "../../Components/PartMaterials/CreatePartMaterialsForm";
import { useEffect, useState} from "react";
function Colors({backendURL, setRowToEdit}) {


    return (
        <>
            <h2>3Designs Colors</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update colors here!</p>
            </div>
            <div class="entityCategory">
                <ColorsTable setRowToEdit={setRowToEdit} backendURL={backendURL}/>
            </div>
        </>
    )
} export default Colors;