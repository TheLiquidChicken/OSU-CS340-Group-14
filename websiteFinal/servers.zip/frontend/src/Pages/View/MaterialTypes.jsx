import React from "react";
import MaterialTypesTable from "../../Components/MaterialTypes/MaterialTypesTable";
import MaterialsTable from "../../Components/Materials/MaterialsTable";
import CreateMaterialsForm from "../../Components/Materials/CreateMaterialsForm";
import PartMaterialsTable from "../../Components/PartMaterials/PartMaterialsTable";
import CreatePartMaterialsForm from "../../Components/PartMachines/CreatePartMachinesForm";
import { useEffect, useState} from "react";
function MaterialTypes({backendURL, setRowToEdit}) {
    return (
        <>
            <h2>3Designs MaterialTypes</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update material types here!</p>
            </div>
            <div class="entityCategory">
                <MaterialTypesTable setRowToEdit={setRowToEdit} backendURL={backendURL}/>
            </div>

        </>
    )
} export default MaterialTypes;