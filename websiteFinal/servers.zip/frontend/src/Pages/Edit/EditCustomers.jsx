import { useEffect } from "react";
import React from "react";
import EditCustomersForm from "../../Components/Customers/EditCustomersForm";


function EditCustomers({backendURL, rowToEdit}){
    return (
        <>
            <h2>Edit Customers</h2>
            <p>Edit a customer below.</p>
            <EditCustomersForm backendURL={backendURL} rowToEdit={rowToEdit}/>
            
        </>
    )
}

export default EditCustomers;