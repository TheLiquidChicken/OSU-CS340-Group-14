import { useEffect } from "react";
import React from "react";
import EditColorsForm from "../../Components/Colors/EditColorsForm";


function EditColors({backendURL, rowToEdit}){
    return (
        <>
            <h2>Edit Color</h2>
            <p>Edit a color below.</p>
            <EditColorsForm backendURL={backendURL} rowToEdit={rowToEdit}/>
            
        </>
    )
}

export default EditColors;