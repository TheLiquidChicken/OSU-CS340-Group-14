import { useEffect } from "react";
import React from "react";
import EditMaterialsForm from "../../Components/Materials/EditMaterialsForm";


function EditMaterials({backendURL, rowToEdit}){
    return (
        <>
            <h2>This is the Edit Material Page.</h2>
            <p>Edit a material below.</p>
            <EditMaterialsForm backendURL={backendURL} rowToEdit={rowToEdit}/>
            
        </>
    )
}

export default EditMaterials;