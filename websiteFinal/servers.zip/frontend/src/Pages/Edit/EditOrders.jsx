import { useEffect } from "react";
import React from "react";
import EditOrdersForm from "../../Components/Orders/EditOrdersForm";


function EditOrders({backendURL, rowToEdit}){
    return (
        <>
            <h2>This is the Edit Order Page.</h2>
            <p>Edit a order below.</p>
            <EditOrdersForm backendURL={backendURL} rowToEdit={rowToEdit}/>
            
        </>
    )
}

export default EditOrders;