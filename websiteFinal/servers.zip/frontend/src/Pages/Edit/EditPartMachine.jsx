import { useEffect } from "react";
import React from "react";
import EditPartMachinesForm from "../../Components/PartMachines/EditPartMachinesForm";


function EditPartMachine({backendURL, rowToEdit}){
    return (
        <>
            <h2>This is the Edit Part Machine Page.</h2>
            <p>Edit a material below.</p>
            <EditPartMachinesForm backendURL={backendURL} rowToEdit={rowToEdit}/>
            
        </>
    )
}

export default EditPartMachine;