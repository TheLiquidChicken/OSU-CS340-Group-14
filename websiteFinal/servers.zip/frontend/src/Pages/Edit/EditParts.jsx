import { useEffect } from "react";
import React from "react";
import EditPartsForm from "../../Components/Parts/EditPartsForm";


function EditParts({backendURL, rowToEdit}){
    return (
        <>
            <h2>This is the Edit Part Page.</h2>
            <p>Edit a part below.</p>
            <EditPartsForm backendURL={backendURL} rowToEdit={rowToEdit}/>
            
        </>
    )
}

export default EditParts;