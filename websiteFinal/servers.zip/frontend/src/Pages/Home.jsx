import React from "react";
function Home({backendURL}) {
    const resetDatabase = async () => {
        const response = await fetch(backendURL + `/reset`, {
                method: 'POST',
                body: JSON.stringify(),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                alert(`Reset Successfully`)
            } else {
                alert(`Query Error, status code = ${response.status}`)
            }
    }
    return (
        <>
            <div className="homepageDescription">
                <h3>Add, remove, and update customers, materials, colors, parts, and orders here!</h3>
                <p>
                    Use the above navigation bar to view customers, materials, parts, colors, and orders. 
                    You can manipulate colors and materialTypes, which are both used to create materials, which is what a roll of filament would be represented as. Materials can be linked to parts through partMaterials, in parts, and materials.
                    You can manipulate parts, which can each be linked to multiple materials and machines through junction tables, which can be found in parts, materials, and machines, depending on which junction table you are looking at.
                    You can manipulate machines, which can have their last maintenance date updated. They can be linked to parts through partmachines, which is in parts and machines.
                    You can manipulate orders, which can be linked to parts through parts. Add an order before a part.
                    You can manipulate customers, which can be linked to orders through the orders page. Add a customer before a order.
                    Overall, you can edit and delete rows on the right options column, and add below the table.
                </p>
                <br/>
                <p>
                    Press the button below to reset the database!
                </p>
                <button onClick={resetDatabase}>
                    Reset
                </button>
            </div>
        </>
    )
} export default Home;
//acquired from https://canvas.oregonstate.edu/courses/2042369/pages/exploration-web-application-technology-2?module_item_id=26640188