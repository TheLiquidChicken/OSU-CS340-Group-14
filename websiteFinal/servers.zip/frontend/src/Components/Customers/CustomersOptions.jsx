import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function CustomersOptions({backendURL, customer, setRowToEdit, refresh}){
    const deleteCustomer = async () => {
        const thisCustomer = customer;
        const response = await fetch(backendURL + `/customers/${thisCustomer.customerID}`, {method: 'DELETE'});
        if(response.status === 204) {
            alert(`Deleted Customer with ID: ${thisCustomer.customerID} Succesfully`)
            refresh();
        } else {
            alert(`No Customer Found with ID or Query Error: ${thisCustomer.customerID}, status code = ${response.status}`)
                const error = await response.json()
                console.error(error)
        }
    }

    const editCustomer = async (customerToEdit)=> {
        setRowToEdit(customerToEdit);
    }
    
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deleteCustomer}/> 

            <Link to="/editcustomers"><CiEdit class="modify" onClick={() => editCustomer(customer)}/></Link>
        </div>
    )
}
export default CustomersOptions;