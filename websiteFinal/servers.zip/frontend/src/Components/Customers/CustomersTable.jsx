import React from "react";
import CustomersRow from "./CustomersRow"
import Customers from "../../Pages/View/Customers";
function CustomersTable({customers, setRowToEdit, backendURL, refresh}){

    return (
        <table>
            <thead>
                <tr>
                    <th>
                        Customer ID
                    </th>
                    <th>
                        Email
                    </th>
                    <th>
                        Phone Number
                    </th>
                    <th>
                        Primary Contact
                    </th>
                    <th>
                        Address
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {customers.map(customer => <CustomersRow customer = {customer}
                                                         refresh = {refresh}
                                                         backendURL = {backendURL}
                                                         setRowToEdit = {setRowToEdit}
                                                         customerID = {customer.customerID}
                                                         email = {customer.email}
                                                         phoneNumber = {customer.phoneNumber}
                                                         primaryContact = {customer.primaryContact}
                                                         address = {customer.address}

                /> )}
            </tbody>
        </table>
    )
}
export default CustomersTable;