// import {useState} from 'react';
// import React from 'react';
//     function EditPartMaterialsForm ({rowToEdit, backendURL}) {
//         const editPartMaterial = async () => {
//             const thisPartMaterial = {partMaterialID:rowToEdit.partMaterialID, materials_materialID:Materials_materialID, parts_partID:Parts_partID}
//             const response = await fetch(backendURL + `/partMaterials/${thisPartMaterial.partMaterialID}`, {
//                 method: 'PUT',
//                 body: JSON.stringify(thisPartMaterial),
//                 headers: { 'Content-Type': 'application/json'}});
//             if(response.status === 200) {
//                 alert(`Edited Part Material with ID: ${thisPartMaterial.partMaterialID} Successfully`)
//             } else {
//                 alert(`No Part Material Found or Query Error with Part Material ID: ${thisPartMaterial.partMaterialID}, status code = ${response.status}`)
//             }
//         }
        
//         const [partMaterialID, setPartMaterialID] = useState(rowToEdit.partMaterialID);
//         const [Materials_materialID, setMaterialID] = useState(rowToEdit.Materials_materialID);
//         const [Parts_partID, setPartID] = useState(rowToEdit.Parts_partID);

//         return (
//             <div>
//                 <form>
//                     <fieldset>
//                         <legend>Edit Part Material With ID: {partMaterialID}</legend>
//             <label>Enter Material ID
//                 <input type="text" className="unit-input" value={Materials_materialID}
//                     onChange={e => setMaterialID(e.target.value)} />
//             </label>
//             <br/>
//             <label>Enter Part ID
//                 <input type="text" className="unit-input" value={Parts_partID}
//                     onChange={e => setPartID(e.target.value)} />
//             </label>
//                     </fieldset>
//                     <button onClick={e => {
//             editPartMaterial();
//             e.preventDefault();
//         }}>Submit</button>
//                 </form>
//             </div>
//         )
//     }



// export default EditPartMaterialsForm;