import {useState} from 'react';
import React from 'react';
    function CreatePartMaterialsForm ({backendURL, refresh}) {
        const createPartMaterial = async () => {
            const thisPartMaterial = {materials_materialID:materials_materialID, parts_partID:parts_partID} 
            const response = await fetch(backendURL + `/partMaterials`, {
                method: 'POST',
                body: JSON.stringify(thisPartMaterial),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                const data = await response.json();
                alert(`Created Part Material Successfully with ID ${data[0]["@newID"]}`);
                refresh();
            } else {
                alert(`Query Error, status code = ${response.status}`)
            }
        }
        
        const [materials_materialID, setMaterialID] = useState();
        const [parts_partID, setPartID] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Part Material</legend>
            <label>Enter Material ID
                <input type="text" className="unit-input" value={materials_materialID}
                    onChange={e => setMaterialID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Part ID
                <input type="text" className="unit-input" value={parts_partID}
                    onChange={e => setPartID(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            createPartMaterial();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default CreatePartMaterialsForm;