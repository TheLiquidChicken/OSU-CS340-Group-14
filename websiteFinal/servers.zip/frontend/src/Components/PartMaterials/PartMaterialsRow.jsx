import React from "react";
import PartMaterialsOptions from "./PartMaterialsOptions.jsx";
function PartMaterialRow({partMaterial, partMaterialID, Materials_materialID, Parts_partID, setRowToEdit, backendURL, refresh}) {
    return(
        <tr>
            <td>
                {partMaterialID}
            </td>
            <td>
                {Materials_materialID}
            </td>
            <td>
                {Parts_partID}
            </td>
            <td>
                <PartMaterialsOptions partMaterial={partMaterial} setRowToEdit={setRowToEdit} backendURL={backendURL} refresh={refresh}/>
            </td>
            
        </tr>
    )
}
export default PartMaterialRow;