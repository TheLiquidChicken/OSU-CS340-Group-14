import React from "react";
function Navigation() {
    return (
        <nav>
            Navigation:
            <a href="/">Home</a>
            <a href="/customers">Customers</a>
            <a href="/colors">Colors</a>
            <a href="/materialTypes">MaterialTypes</a>
            <a href="/parts">Parts</a>
            <a href="/orders">Orders</a>
            <a href="/machines">Machines</a>
            <a href="/materials">Materials</a>
        </nav>
    )
} export default Navigation;
