import {useState} from 'react';
import React from 'react';
    function createMaterialsForm ({backendURL, refresh}) {
        const createMaterial = async () => {
            const thisMaterial = {MaterialTypes_materialTypeID:Materials_materialTypeID, Colors_colorID:Colors_colorID, kilograms:kilograms} 
            const response = await fetch(backendURL + `/materials`, {
                method: 'POST',
                body: JSON.stringify(thisMaterial),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                const data = await response.json();
                alert(`Created Material Successfully with ID ${data[0]["@newID"]}`);
                refresh();
            } else {
                alert(`Query Error, status code = ${response.status}`)
                const error = await response.json()
                console.error(error)
            }
        }
        const [Materials_materialTypeID, setMaterialTypeID] = useState();
        const [Colors_colorID, setColorID] = useState();
        const [kilograms, setKilograms] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Material</legend>
            <label>Enter Material Type ID
                <input type="text" className="unit-input" value={Materials_materialTypeID}
                    onChange={e => setMaterialTypeID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Material Color
                <input type="text" className="unit-input" value={Colors_colorID}
                    onChange={e => setColorID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Kilograms
                <input type="text" className="unit-input" value={kilograms}
                    onChange={e => setKilograms(e.target.value)} />
            </label>
                    </fieldset>
                </form>
                <button onClick={e => {
            createMaterial();
            e.preventDefault();
        }}>Submit</button>
            </div>
        )
    }



export default createMaterialsForm;