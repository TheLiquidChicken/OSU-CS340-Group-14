import React from "react";
import MaterialsOptions from "./MaterialsOptions.jsx";
function MaterialsRow({backendURL, material, materialID, MaterialTypes_materialTypeID, Colors_colorID, kilograms, setRowToEdit, refresh}) {
    return(
        <tr>
            <td>
                {materialID}
            </td>
            <td>
                {MaterialTypes_materialTypeID}
            </td>
            <td>
                {Colors_colorID}
            </td>
            <td>
                {kilograms}
            </td>
            <td>
                <MaterialsOptions backendURL={backendURL} material={material} setRowToEdit={setRowToEdit} refresh={refresh}/>
            </td>
            
        </tr>
    )
}
export default MaterialsRow;