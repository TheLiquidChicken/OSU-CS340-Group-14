import {useState} from 'react';
import React from 'react';
    function editMachineForm ({rowToEdit, backendURL}) {
        const editMachine = async () => {
            console.log('Edit Machine Executed')
            const thisMachine = {machineID:rowToEdit.machineID, machineDescription:machineDescription, lastServiceDate:lastServiceDate}
            const response = await fetch(backendURL + `/machines/${thisMachine.machineID}`, {
                method: 'PUT',
                body: JSON.stringify(thisMachine),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 200) {
                alert(`Edited Machine with ID: ${thisMachine.machineID} Successfully`)
            } else {
                alert(`No Machine Found or Query Error with Machine ID: ${thisMachine.machineID}, status code = ${response.status}`)
                const error = await response.json()
                console.error(error)
            }
        }
        
        const [machineDescription, setMachineDescription] = useState(rowToEdit.machineDescription);
        const [lastServiceDate, setLastServiceDate] = useState(rowToEdit.lastServiceDate);

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Edit Machine with ID: {rowToEdit.machineID}</legend>
            <label>Enter Machine Description
                <input type="text" className="unit-input" value={machineDescription}
                    onChange={e => setRevenue(e.target.value)} />
            </label>
            <br/>
            <label>Enter Last Service Date
                <input type="date" className="unit-input" value={lastServiceDate}
                    onChange={e => setLastServiceDate(e.target.value)} />
            </label>
            <br/>
                    </fieldset>
                    <button onClick={e => {
            editMachine();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default editMachineForm;