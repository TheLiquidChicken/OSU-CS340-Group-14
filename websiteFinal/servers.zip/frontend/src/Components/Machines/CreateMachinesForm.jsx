import {useState} from 'react';
import React from 'react';
    function createMachineForm ({backendURL, refresh}) {
        const createMachine = async () => {
            console.log('Edit Machine Executed')
            const thisMachine = {machineDescription:machineDescription, lastServiceDate:lastServiceDate}
            const response = await fetch(backendURL + `/machines`, {
                method: 'POST',
                body: JSON.stringify(thisMachine),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                const data = await response.json();
                alert(`Created Machine Successfully with ID ${data[0]["@newID"]}`);
                refresh();
            } else {
                alert(`Query Error, status code = ${response.status}`)
                const error = await response.json()
                console.error(error)
            }
        }
        
        const [machineDescription, setMachineDescription] = useState();
        const [lastServiceDate, setLastServiceDate] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Order</legend>
            <label>Enter Machine Description
                <input type="text" className="unit-input" value={machineDescription}
                    onChange={e => setMachineDescription(e.target.value)} />
            </label>
            <br/>
            <label>Enter Last Service Date
                <input type="date" className="unit-input" value={lastServiceDate}
                    onChange={e => setLastServiceDate(e.target.value)} />
            </label>
            <br/>
                    </fieldset>
                    <button onClick={e => {
            createMachine();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default createMachineForm;