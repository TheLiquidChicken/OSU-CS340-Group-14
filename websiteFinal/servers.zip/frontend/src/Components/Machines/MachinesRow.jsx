import React from "react";
import MachineOptions from "./MachineOptions.jsx";
function MachinesRow({backendURL, machine, machineID, machineDescription, lastServiceDate, setRowToEdit, refresh}) {

    return(
        <tr>
            <td>
                {machineID}
            </td>
            <td>
                {machineDescription}
            </td>
            <td>
                {lastServiceDate.toString().split('T')[0]}
            </td>
            <td>
                <MachineOptions refresh={refresh} machine={machine} setRowToEdit={setRowToEdit} backendURL={backendURL}/>
            </td>
            
        </tr>
    )
}
export default MachinesRow;