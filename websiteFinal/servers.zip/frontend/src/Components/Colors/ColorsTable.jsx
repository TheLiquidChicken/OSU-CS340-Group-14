import React from "react";
import ColorsRow from "./ColorsRow"
import Colors from "../../Pages/View/Colors";
import { useState, useEffect } from "react";
import CreateColorsForm from "../../Components/Colors/CreateColorsForm";
function ColorsTable({setRowToEdit, backendURL}){
    //refreshes the component and gets data again
    const [count, setCount] = useState(0);
    const refresh = () => {
        setCount(count+1);
        loadData();
    };

    const [colors, setColors] = useState([]);
    useEffect(() => {
        loadData();
    }, []
    )   
    const loadData = async () => {
        const response = await fetch(backendURL + '/colors');
        const data = await response.json();
        if(response.status === 200) {
        setColors(data.colors);
        } else {
            const error = await response.json();
            console.error(error);
        }
    }
    return (
    <div>    
        <table>
            <thead>
                <tr>
                    <th>
                        Color ID
                    </th>
                    <th>
                        Color Description
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {colors.map(color => <ColorsRow 
                    refresh = {refresh}
                    backendURL= {backendURL}
                    color = {color}
                    colorID = {color.colorID}
                    colorDescription = {color.colorDescription}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
        <CreateColorsForm backendURL={backendURL} refresh={refresh}/>
    </div>
    )
}
export default ColorsTable;