import React from "react";
import ColorsOptions from "./ColorsOptions.jsx";
function ColorsRow({color, colorID, colorDescription, setRowToEdit, backendURL, refresh}) {

    return(
        <tr>
            <td>
                {colorID}
            </td>
            <td>
                {colorDescription}
            </td>
            <td>
                <ColorsOptions color={color} setRowToEdit={setRowToEdit} backendURL={backendURL} refresh={refresh}/>
            </td>
            
        </tr>
    )
}
export default ColorsRow;