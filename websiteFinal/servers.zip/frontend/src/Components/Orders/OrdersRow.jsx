import React from "react";
import OrdersOptions from "./OrdersOptions.jsx";
function OrdersRow({order, orderID, revenue, date, customers_customerID, setRowToEdit, backendURL, refresh}) {
    return(
        <tr>
            <td>
                {orderID}
            </td>
            <td>
                {revenue}
            </td>
            <td>
                {date.toString().split('T')[0]}
            </td>
            <td>
                {customers_customerID}
            </td>
            <td>
                <OrdersOptions order={order} setRowToEdit={setRowToEdit} backendURL={backendURL} refresh={refresh}/>
            </td>
            
        </tr>
    )
}
export default OrdersRow;