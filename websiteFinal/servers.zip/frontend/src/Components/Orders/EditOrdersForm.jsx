import {useState} from 'react';
import React from 'react';
    function editOrderForm ({rowToEdit, backendURL}) {
        const editOrder = async () => {
            const thisOrder = {orderID:rowToEdit.orderID, revenue:revenue, date:date, customers_customerID:customers_customerID}
            const response = await fetch(backendURL + `/orders/${thisOrder.orderID}`, {
                method: 'PUT',
                body: JSON.stringify(thisOrder),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 200) {
                alert(`Edited Order with ID: ${thisOrder.orderID} Successfully`)
            } else {
                alert(`No Order Found or Query Error with Order ID: ${thisOrder.orderID}, status code = ${response.status}`)
                const error = await response.json()
                console.error(error)
            }
        }
        
        const [revenue, setRevenue] = useState(rowToEdit.revenue);
        const [date, setDate] = useState(rowToEdit.date);
        const [customers_customerID, setCustomers_customerID] = useState(rowToEdit.customers_customerID);

        return (
            <div>
                <h3>Order ID is {rowToEdit.orderID}</h3>
                <form>
                    <fieldset>
                        <legend>Edit Order</legend>
            <label>Enter Revenue
                <input type="number" className="unit-input" value={revenue}
                    onChange={e => setRevenue(e.target.value)} />
            </label>
            <br/>
            <label>Enter Date
                <input type="date" className="unit-input" value={date}
                    onChange={e => setDate(e.target.value)} />
            </label>
            <br/>
            <label>Enter CustomerID
                <input type="text" className="unit-input" value={customers_customerID}
                    onChange={e => setCustomers_customerID(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            editOrder();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default editOrderForm;