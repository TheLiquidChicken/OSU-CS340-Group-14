import {useState} from 'react';
import React from 'react';
    function createPartMachinesForm ({backendURL, refresh}) {
        const createPartMachine = async () => {
            const thisPartMachine = {machines_machineID:machines_machineID, parts_partID:parts_partID} 
            const response = await fetch(backendURL + `/partMachines`, {
                method: 'POST',
                body: JSON.stringify(thisPartMachine),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                const data = await response.json();
                alert(`Created Part Machine Successfully with ID ${data[0]["@newID"]}`);
                refresh();
            } else {
                alert(`Query Error, status code = ${response.status}`)
            }
        }
        
        const [machines_machineID, setMachineID] = useState();
        const [parts_partID, setPartID] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Part Machine</legend>
            <label>Enter MachineID
                <input type="text" className="unit-input" value={machines_machineID}
                    onChange={e => setMachineID(e.target.value)} />
            </label>
            <br/>
            <label>Enter PartID
                <input type="text" className="unit-input" value={parts_partID}
                    onChange={e => setPartID(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            createPartMachine();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default createPartMachinesForm;