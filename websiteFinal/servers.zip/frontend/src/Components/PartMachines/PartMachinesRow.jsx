import React from "react";
import PartMachineOptions from "./PartMachinesOptions.jsx";
function PartMachineRow({partMachine, partMachineID, Machines_machineID, Parts_partID, setRowToEdit, backendURL, refresh}) {
    return(
        <tr>
            <td>
                {partMachineID}
            </td>
            <td>
                {Machines_machineID}
            </td>
            <td>
                {Parts_partID}
            </td>
            <td>
                <PartMachineOptions partMachine={partMachine} setRowToEdit={setRowToEdit} backendURL={backendURL} refresh={refresh}/>
            </td>
            
        </tr>
    )
}
export default PartMachineRow;