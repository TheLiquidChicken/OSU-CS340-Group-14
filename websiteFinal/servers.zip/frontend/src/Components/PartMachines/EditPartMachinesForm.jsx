// import {useState} from 'react';
// import React from 'react';
//     function EditPartMachinesForm ({rowToEdit}) {
//         const editPartMachine = async () => {
//             const thisPartMachine = {partMachineID:rowToEdit.partMachineID, Machines_machineID:Machines_machineID, Parts_partID:Parts_partID}
//             const response = await fetch(backendURL + `/partMachines/${thisPartMachine.partMachineID}`, {
//                 method: 'PUT',
//                 body: JSON.stringify(thisPartMachine),
//                 headers: { 'Content-Type': 'application/json'}});
//             if(response.status === 200) {
//                 alert(`Edited Part Machine with ID: ${thisPartMachine.partMachineID} Successfully`)
//             } else {
//                 alert(`No Part Machine Found or Query Error with Part Machine ID: ${thisPartMachine.partMachineID}, status code = ${response.status}`)
//             }
//         }
        
//         const [partMachineID, setPartMachineID] = useState(rowToEdit.partMachineID);
//         const [Machines_machineID, setMachineID] = useState(rowToEdit.Machines_machineID);
//         const [Parts_partID, setPartID] = useState(rowToEdit.Parts_partID);

//         return (
//             <div>
//                 <form>
//                     <fieldset>
//                         <legend>Edit PartMachine of PartMachine ID: {partMachineID}</legend>
//             <label>Enter MachineID
//                 <input type="text" className="unit-input" value={Machines_machineID}
//                     onChange={e => setMachineID(e.target.value)} />
//             </label>
//             <br/>
//             <label>Enter PartID
//                 <input type="text" className="unit-input" value={Parts_partID}
//                     onChange={e => setPartID(e.target.value)} />
//             </label>
//                     </fieldset>
//                     <button onClick={e => {
//             editPartMachine();
//             e.preventDefault();
//         }}>Submit</button>
//                 </form>
//             </div>
//         )
//     }



// export default EditPartMachinesForm;