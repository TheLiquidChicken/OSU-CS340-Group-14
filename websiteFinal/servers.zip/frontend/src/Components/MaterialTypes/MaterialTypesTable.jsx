import React from "react";
import MaterialTypesRow from "./MaterialTypesRow"
import MaterialTypes from "../../Pages/View/MaterialTypes";
import CreateMaterialTypeForm from "../../Components/MaterialTypes/CreateMaterialTypesForm";
import { useEffect, useState} from "react";
function MaterialTypesTable({setRowToEdit, backendURL}){
    //refreshes the component and gets data again
    const [count, setCount] = useState(0);
    const refresh = () => {
        setCount(count+1);
        loadData();
    };

    const [materialTypes, setMaterialTypes] = useState([]);
    useEffect(() => {
        loadData();
    }, []
    )   
    const loadData = async () => {
        const response = await fetch(backendURL + '/materialTypes');
        const data = await response.json();
        if(response.status === 200) {
            setMaterialTypes(data.materialTypes);
        } else {
            const error = await response.json();
            console.error(error);
        }

    }
    
    return (
    <div>
        <table>
            <thead>
                <tr>
                    <th>
                        Material Type ID
                    </th>
                    <th>
                        Material Type Description
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {materialTypes.map(materialType => <MaterialTypesRow 
                    refresh = {refresh}
                    backendURL = {backendURL}
                    materialType = {materialType}
                    materialTypeID = {materialType.materialTypeID}
                    materialTypeDescription = {materialType.materialTypeDescription}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
        <br/>
        <CreateMaterialTypeForm backendURL={backendURL} refresh={refresh}/>
    </div>
    )
}
export default MaterialTypesTable;