import React from "react";
import MaterialTypesOptions from "./MaterialTypesOptions.jsx";
function MaterialTypesRow({materialType, materialTypeID, materialTypeDescription, setRowToEdit, backendURL, refresh}) {
    return(
        <tr>
            <td>
                {materialTypeID}
            </td>
            <td>
                {materialTypeDescription}
            </td>
            <td>
                <MaterialTypesOptions refresh={refresh} backendURL={backendURL} materialType={materialType} setRowToEdit={setRowToEdit}/>
            </td>
            
        </tr>
    )
}
export default MaterialTypesRow;