import React from "react";
import PartsOptions from "./PartsOptions.jsx";
function PartsRow({setRowToEdit, backendURL, part, partID, partName, partPath, quantity, mass, infillDensity, orders_orderID, refresh}) {

    return(
        <tr>
            <td>
                {partID}
            </td>
            <td>
                {partName}
            </td>
            <td>
                {partPath}
            </td>
            <td>
                {quantity}
            </td>
            <td>
                {mass}
            </td>
            <td>
                {infillDensity}
            </td>
            <td>
                {orders_orderID}
            </td>
            <td>
                <PartsOptions part={part} setRowToEdit={setRowToEdit} backendURL={backendURL} refresh={refresh}/>
            </td>
            
        </tr>
    )
}
export default PartsRow;