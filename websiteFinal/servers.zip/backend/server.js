/*Citation for the following code
* 6/4/26
* Adapted From CS340 Material at link https://canvas.oregonstate.edu/courses/2042369/pages/exploration-web-application-technology-2?module_item_id=26640188
* Modified base database code and changed routes to matche entities and call the stored functions
* No AI tools were used
*/

// ########################################
// ########## SETUP

// Database
const db = require('./database/db-connector');

// Express
const express = require('express');
const app = express();

// Middleware
const cors = require('cors');
app.use(cors({ credentials: true, origin: "*" }));
app.use(express.json()); // this is needed for post requests


const PORT = 42566;

// ########################################
// ########## ROUTE HANDLERS

// READ ROUTES
//CUSTOMERS
app.get('/customers', async (req, res) => {
    try {
        // Create and execute our queries
        // In query1, we use a JOIN clause to display the names of the homeworlds
        //const query1 = `SELECT bsg_people.id, bsg_people.fname, bsg_people.lname, \
        //    bsg_planets.name AS 'homeworld', bsg_people.age FROM bsg_people \
        //    LEFT JOIN bsg_planets ON bsg_people.homeworld = bsg_planets.id;`;
        //const query2 = 'SELECT * FROM bsg_planets;';
        //const [customers] = await db.query(query1);
        //const [homeworlds] = await db.query(query2);
        // const customers = [{customerID:1, email:"BevH@amail.com", phoneNumber:"(800)555-1285", primaryContact:"Beverly Hanson", address:"2500 Victory Park Lane, 87143 Corvallis Oregon"},
        //     {customerID:2, email:"SamA@amail.com", phoneNumber:"(800)555-7836", primaryContact:"Sam Alexander", address:"8935 1st Street, 84783 Eugene Oregon"},
        //     {customerID:3, email:"ChrisF@amail.com", phoneNumber:"(800)555-5983", primaryContact:"Chris Fabela", address:"7496 20th Street, 98542 Hillsboro Oregon"}
        // ]

    const query1 = `CALL sp_SelectCustomers()`;
    const [result] = await db.query(query1);
    const customers = result[0]
        res.status(200).json({ customers });  // Send the results to the frontend

    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
     
});

app.post('/customers', async (req, res) => {
    try {
            const query1 = `CALL sp_InsertCustomer('${req.body.email}', '${req.body.phoneNumber}', '${req.body.primaryContact}', '${req.body.address}', @newID)`
            const query2 = `SELECT @newID;`
            await db.query(query1);
            const [newID] = await db.query(query2);
        res.status(201).json(newID)
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
});

app.put('/customers/:customerID', async (req, res) => {
    try {
        const query1 = `CALL sp_UpdateCustomer(${req.params.customerID}, '${req.body.email}', '${req.body.phoneNumber}', '${req.body.primaryContact}', '${req.body.address}')`
        await db.query(query1);
            res.status(200).json()
    } catch (error)     {
        console.error("Error executing queries:", error);
        res.status(500).json(error);
    }
})
app.delete('/customers/:customerID', async (req, res) => {
    try {
        const query1 = `CALL sp_DeleteCustomer(${req.params.customerID})`
        await db.query(query1);
        res.status(204).json();
    } catch {
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})

//Colors
app.get('/colors', async (req, res) => {
    try {
        // Create and execute our queries
        // In query1, we use a JOIN clause to display the names of the homeworlds
        //const query1 = `SELECT bsg_people.id, bsg_people.fname, bsg_people.lname, \
        //    bsg_planets.name AS 'homeworld', bsg_people.age FROM bsg_people \
        //    LEFT JOIN bsg_planets ON bsg_people.homeworld = bsg_planets.id;`;
        //const query2 = 'SELECT * FROM bsg_planets;';
        //const [customers] = await db.query(query1);
        //const [homeworlds] = await db.query(query2);
        //const colors = [{colorID:"OVTR-BLUE", colorDescription:"Blue"}, {colorID:"OVTR-PURPLE", colorDescription:"Purple"}, {colorID:"OVTR-RED", colorDescription:"Red"}]
        
    const query1 = `CALL sp_selectColors()`;
    const [result] = await db.query(query1);
    const colors = result[0]

        res.status(200).json({ colors });  // Send the results to the frontend

    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
    
});

app.post('/colors', async (req, res) => {
    try {
            const query1 = `CALL sp_InsertColor('${req.body.colorID}', '${req.body.colorDescription}', @newID)`
            const query2 = `SELECT @newID;`
            await db.query(query1);
            const [newID] = await db.query(query2);
        res.status(201).json(newID)
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
});

app.put('/colors/:colorID', async (req, res) => {
    try {
        const query1 = `CALL sp_UpdateColor('${req.params.colorID}', '${req.body.colorID}', '${req.body.colorDescription}')`
        await db.query(query1);
            res.status(200).json()
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})
app.delete('/colors/:colorID', async (req, res) => {
    try {
        const query1 = `CALL sp_DeleteColor('${req.params.colorID}')`
        await db.query(query1);
        res.status(204).json();
    } catch (error) {
        console.error(error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})

//Machines
app.get('/machines', async (req, res) => {
    try {
        // Create and execute our queries
        // In query1, we use a JOIN clause to display the names of the homeworlds
        //const query1 = `SELECT bsg_people.id, bsg_people.fname, bsg_people.lname, \
        //    bsg_planets.name AS 'homeworld', bsg_people.age FROM bsg_people \
        //    LEFT JOIN bsg_planets ON bsg_people.homeworld = bsg_planets.id;`;
        //const query2 = 'SELECT * FROM bsg_planets;';
        //const [customers] = await db.query(query1);
        //const [homeworlds] = await db.query(query2);
        // const machines = [{machineID:1, machineDescription:"Ultimaker S3", lastServiceDate:"2026-04-29"},
        //     {machineID:2, machineDescription:"Ultimaker S5", lastServiceDate:"2026-04-22"},
        //     {machineID:3, machineDescription:"Bambu X1C", lastServiceDate:"2026-04-18"}
        // ];   

        const query1 = `CALL sp_SelectMachines()`;
        const [result] = await db.query(query1);
        const machines = result[0]
        res.status(200).json({ machines });  // Send the results to the frontend

    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
    
});

app.post('/machines', async (req, res) => {
    try {
            const query1 = `CALL sp_InsertMachine('${req.body.machineDescription}', '${req.body.lastServiceDate}', @newID)`
            const query2 = `SELECT @newID;`
            await db.query(query1);
            const [newID] = await db.query(query2);
        res.status(201).json(newID)
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
});

app.put('/machines/:machineID', async (req, res) => {
    try {
        const query1 = `CALL sp_UpdateMachine(${req.params.machineID}, '${req.body.machineDescription}', '${req.body.lastServiceDate}')`
        await db.query(query1);
            res.status(200).json()
    } catch {
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})
app.delete('/machines/:machineID', async (req, res) => {
    try {
        const query1 = `CALL sp_DeleteMachine(${req.params.machineID})`
        await db.query(query1);
        res.status(204).json();
    } catch {
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})

//Materials
app.get('/materials', async (req, res) => {
    try {
        // Create and execute our queries
        // In query1, we use a JOIN clause to display the names of the homeworlds
        //const query1 = `SELECT bsg_people.id, bsg_people.fname, bsg_people.lname, \
        //    bsg_planets.name AS 'homeworld', bsg_people.age FROM bsg_people \
        //    LEFT JOIN bsg_planets ON bsg_people.homeworld = bsg_planets.id;`;
        //const query2 = 'SELECT * FROM bsg_planets;';
        //const [customers] = await db.query(query1);
        //const [homeworlds] = await db.query(query2);
        // const materials = [{materialID:1, kilograms:5, MaterialTypes_materialTypeID:"OVTR-PLA", Colors_colorID:"OVTR-RED"},
        //     {materialID:2, kilograms:8, MaterialTypes_materialTypeID:"OVTR-PETG", Colors_colorID:"OVTR-BLUE"},
        //     {materialID:3, kilograms:11, MaterialTypes_materialTypeID:"OVTR-NYLON", Colors_colorID:"OVTR-PURPLE"}
        // ];
        const query1 = `CALL sp_SelectMaterials()`;
        const [result] = await db.query(query1);
        const materials = result[0]
        res.status(200).json({ materials });  // Send the results to the frontend

    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
    
});

app.post('/materials', async (req, res) => {
    try {
            const query1 = `CALL sp_insertMaterial('${req.body.MaterialTypes_materialTypeID}', '${req.body.Colors_colorID}', ${req.body.kilograms}, @newID)`
            const query2 = `SELECT @newID;`
            await db.query(query1);
            const [newID] = await db.query(query2);
        res.status(201).json(newID)
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
});

app.put('/materials/:materialID', async (req, res) => {
                console.log(req.body)
    try {
        const query1 = `CALL sp_UpdateMaterial('${req.params.materialID}', ${req.body.kilograms})`
        await db.query(query1);
            res.status(200).json()
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})
app.delete('/materials/:materialID', async (req, res) => {
    try {
        const query1 = `CALL sp_DeleteMaterial(${req.params.materialID})`
        await db.query(query1);
        res.status(204).json();
    } catch {
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})

//MaterialTypes
app.get('/materialTypes', async (req, res) => {
    try {
        // Create and execute our queries
        // In query1, we use a JOIN clause to display the names of the homeworlds
        //const query1 = `SELECT bsg_people.id, bsg_people.fname, bsg_people.lname, \
        //    bsg_planets.name AS 'homeworld', bsg_people.age FROM bsg_people \
        //    LEFT JOIN bsg_planets ON bsg_people.homeworld = bsg_planets.id;`;
        //const query2 = 'SELECT * FROM bsg_planets;';
        //const [customers] = await db.query(query1);
        //const [homeworlds] = await db.query(query2);
        // const materialTypes = [{materialTypeID:"OVTR-NYLON", materialTypeDescription:"NYLON"},
        //     {materialTypeID:"OVTR-PETG", materialTypeDescription:"PETG"},
        //     {materialTypeID:"OVTR-PLA", materialTypeDescription:"PLA"}
        // ];

    
    const query1 = `CALL sp_SelectMaterialTypes()`;
    const [result] = await db.query(query1);
    const materialTypes = result[0]
        res.status(200).json({ materialTypes });  // Send the results to the frontend

    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
    
});

app.post('/materialTypes', async (req, res) => {
    try {
            const query1 = `CALL sp_InsertMaterialType('${req.body.materialTypeID}', '${req.body.materialTypeDescription}', @newID)`
            const query2 = `SELECT @newID;`
            await db.query(query1);
            const [newID] = await db.query(query2);
        res.status(201).json(newID)
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
});

app.put('/materialTypes/:materialTypeID', async (req, res) => {
    try {
        const query1 = `CALL sp_UpdateMaterialType('${req.params.materialTypeID}', '${req.body.materialTypeID}', '${req.body.materialTypeDescription}')`
        await db.query(query1);
            res.status(200).json()
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})
app.delete('/materialTypes/:materialTypeID', async (req, res) => {
    try {
        const query1 = `CALL sp_DeleteMaterialType('${req.params.materialTypeID}')`
        const result = await db.query(query1);
        res.status(204).json();
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})

//Orders
app.get('/orders', async (req, res) => {
    try {
        // Create and execute our queries
        // In query1, we use a JOIN clause to display the names of the homeworlds
        //const query1 = `SELECT bsg_people.id, bsg_people.fname, bsg_people.lname, \
        //    bsg_planets.name AS 'homeworld', bsg_people.age FROM bsg_people \
        //    LEFT JOIN bsg_planets ON bsg_people.homeworld = bsg_planets.id;`;
        //const query2 = 'SELECT * FROM bsg_planets;';
        //const [customers] = await db.query(query1);
        //const [homeworlds] = await db.query(query2);
        // const orders = [{orderID:1, revenue:300.32, date:"2024-01-05", customers_customerID:1},
        //     {orderID:2, revenue:832.56, date:"2025-03-16", customers_customerID:2},
        //     {orderID:3, revenue:983.87, date:"2025-06-21", customers_customerID:3},
        //     {orderID:4, revenue:895.34, date:"2026-02-03", customers_customerID:3}
        // ];
    
    const query1 = `CALL sp_SelectOrders()`;
    const [result] = await db.query(query1);
    const orders = result[0]
        res.status(200).json({ orders });  // Send the results to the frontend
        

    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
    
});

app.post('/orders', async (req, res) => {
    try {
            const query1 = `CALL sp_InsertOrder('${req.body.revenue}', ${req.body.customers_customerID}, '${req.body.date}', @newID)`
            const query2 = `SELECT @newID;`
            await db.query(query1);
            const [newID] = await db.query(query2);
        res.status(201).json(newID)
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
});

app.put('/orders/:orderID', async (req, res) => {
    try {
        const query1 = `CALL sp_UpdateOrder(${req.params.orderID}, '${req.body.revenue}', ${req.body.customers_customerID}, '${req.body.date}')`
        await db.query(query1);
            res.status(200).json()
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})
app.delete('/orders/:orderID', async (req, res) => {
    try {
        const query1 = `CALL sp_DeleteOrder(${req.params.orderID})`
        await db.query(query1);
        res.status(204).json();
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})

//PartMachines
app.get('/partMachines', async (req, res) => {
    try {
        // Create and execute our queries
        // In query1, we use a JOIN clause to display the names of the homeworlds
        //const query1 = `SELECT bsg_people.id, bsg_people.fname, bsg_people.lname, \
        //    bsg_planets.name AS 'homeworld', bsg_people.age FROM bsg_people \
        //    LEFT JOIN bsg_planets ON bsg_people.homeworld = bsg_planets.id;`;
        //const query2 = 'SELECT * FROM bsg_planets;';
        //const [customers] = await db.query(query1);
        //const [homeworlds] = await db.query(query2);
        // const partMachines = [
        //     {partMachineID:1, Machines_machineID:1, Parts_partID:1},
        //     {partMachineID:2, Machines_machineID:1, Parts_partID:2},
        //     {partMachineID:3, Machines_machineID:2, Parts_partID:3},
        //     {partMachineID:4, Machines_machineID:3, Parts_partID:4},
        //     {partMachineID:5, Machines_machineID:3, Parts_partID:5}
        // ];

    const query1 = `CALL sp_SelectPartMachines()`;
    const [result] = await db.query(query1);
    const partMachines = result[0]
        res.status(200).json({ partMachines });  // Send the results to the frontend

    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
    
});

app.post('/partMachines', async (req, res) => {
    try {
            const query1 = `CALL sp_InsertPartMachine(${req.body.parts_partID}, ${req.body.machines_machineID}, @newID)`
            const query2 = `SELECT @newID;`
            await db.query(query1);
            const [newID] = await db.query(query2);
        res.status(201).json(newID)
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
});

// app.put('/partMachines/:partMachineID', async (req, res) => {
//     try {
//         const query1 = `CALL sp_UpdatePartMachine(${req.params.partMachineID}, ${req.body.parts_partID}, ${req.body.machines_machineID}, @newID)`
//         await db.query(query1);
//             res.status(200).json()
//     } catch (error) {
//         console.error("Error executing queries:", error);
//         // Send a generic error message to the browser
//         res.status(500).json(error);
//     }
// })
app.delete('/partMachines/:partMachineID', async (req, res) => {
    try {
        const query1 = `CALL sp_DeletePartMachine(${req.params.partMachineID})`
        await db.query(query1);
        res.status(204).json();
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})

//PartMaterials
app.get('/partMaterials', async (req, res) => {
    try {
        // Create and execute our queries
        // In query1, we use a JOIN clause to display the names of the homeworlds
        //const query1 = `SELECT bsg_people.id, bsg_people.fname, bsg_people.lname, \
        //    bsg_planets.name AS 'homeworld', bsg_people.age FROM bsg_people \
        //    LEFT JOIN bsg_planets ON bsg_people.homeworld = bsg_planets.id;`;
        //const query2 = 'SELECT * FROM bsg_planets;';
        //const [customers] = await db.query(query1);
        //const [homeworlds] = await db.query(query2);
        // const partMaterials = [
        //     {partMaterialID:1, Materials_materialID:1, Parts_partID:1},
        //     {partMaterialID:2, Materials_materialID:2, Parts_partID:1},
        //     {partMaterialID:3, Materials_materialID:3, Parts_partID:2},
        //     {partMaterialID:4, Materials_materialID:4, Parts_partID:3},
        //     {partMaterialID:5, Materials_materialID:5, Parts_partID:3}
        // ];
    const query1 = `CALL sp_SelectPartMaterials()`;
    const [result] = await db.query(query1);
    const partMaterials = result[0]
        res.status(200).json({ partMaterials });  // Send the results to the frontend

    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
    
});

app.post('/partMaterials', async (req, res) => {
    try {
            const query1 = `CALL sp_InsertPartMaterial(${req.body.parts_partID}, ${req.body.materials_materialID}, @newID)`
            const query2 = `SELECT @newID;`
            await db.query(query1);
            const [newID] = await db.query(query2);
        res.status(201).json(newID)
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
});

// app.put('/partMaterials/:partMaterialID', async (req, res) => {
//     try {
//         const query1 = `CALL sp_UpdatePartMaterial(${req.params.partMaterialID}, ${req.body.parts_partID}, ${req.body.materials_materialID})`
//         await db.query(query1);
//             res.status(200).json()
//     } catch (error) {
//         console.error("Error executing queries:", error);
//         // Send a generic error message to the browser
//         res.status(500).json(error);
//     }
// })
app.delete('/partMaterials/:partMaterialID', async (req, res) => {
    try {
        const query1 = `CALL sp_DeletePartMaterial(${req.params.partMaterialID})`
        await db.query(query1);
        res.status(204).json();
    } catch (error) {
        console.error("Error executing queries:", error);
        res.status(500).json(error);
    }
})

//Parts
app.get('/parts', async (req, res) => {
    try {
        // Create and execute our queries
        // In query1, we use a JOIN clause to display the names of the homeworlds
        //const query1 = `SELECT bsg_people.id, bsg_people.fname, bsg_people.lname, \
        //    bsg_planets.name AS 'homeworld', bsg_people.age FROM bsg_people \
        //    LEFT JOIN bsg_planets ON bsg_people.homeworld = bsg_planets.id;`;
        //const query2 = 'SELECT * FROM bsg_planets;';
        //const [customers] = await db.query(query1);
        //const [homeworlds] = await db.query(query2);
        // const parts = [
        //     {partID:1, partName:"Boat", partPath:"files/boat.stl", quantity:15, mass:12, infillDensity:20, orders_orderID:1},
        //     {partID:2, partName:"Bracket", partPath:"files/bracket.stl", quantity:4, mass:53, infillDensity:80, orders_orderID:2},
        //     {partID:3, partName:"Gear", partPath:"files/gear.stl", quantity:30, mass:34, infillDensity:90, orders_orderID:3},
        //     {partID:4, partName:"SidePanelLower", partPath:"files/SidePanelLower.stl", quantity:2, mass:300, infillDensity:100, orders_orderID:4},
        //     {partID:5, partName:"SidePanelUpper", partPath:"files/SidePanelUpper.stl", quantity:2, mass:300, infillDensity:100, orders_orderID:4}
        // ];
        
    const query1 = `CALL sp_SelectParts()`;
    const [result] = await db.query(query1);
    const parts = result[0]
        res.status(200).json({ parts });  // Send the results to the frontend
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
    
});

app.post('/parts', async (req, res) => {
    try {
            const query1 = `CALL sp_InsertPart('${req.body.partName}', '${req.body.partPath}', ${req.body.quantity}, ${req.body.mass}, ${req.body.infillDensity}, ${req.body.orders_orderID}, @newID)`
            const query2 = `SELECT @newID;`
            await db.query(query1);
            const [newID] = await db.query(query2);
        res.status(201).json(newID)
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
});

app.put('/parts/:partID', async (req, res) => {
    try {
        const query1 = `CALL sp_UpdatePart(${req.params.partID},'${req.body.partName}', '${req.body.partPath}', ${req.body.quantity}, ${req.body.mass}, ${req.body.infillDensity}, ${req.body.orders_orderID})`
        await db.query(query1);
            res.status(200).json()
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})
app.delete('/parts/:partID', async (req, res) => {
    try {
        const query1 = `CALL sp_DeletePart(${req.params.partID})`
        await db.query(query1);
        res.status(204).json();
    } catch (error) {
        console.error("Error executing queries:", error);
        // Send a generic error message to the browser
        res.status(500).json(error);
    }
})

//Reset Database
app.post('/reset', async (req, res) => {
    try {
        const query1 = `CALL sp_ResetDatabase()`;
        await db.query(query1);
        res.status(201).json()
    } catch (error) {
        console.error(error);
        res.status(500).json(error);
    }
})

// ########################################
// ########## LISTENER

app.listen(PORT, function () {
    console.log('Express started on http://classwork.engr.oregonstate.edu:' + PORT + '; press Ctrl-C to terminate.');
});