/*Citation for the following code
* 6/4/26
* Adapted From CS340 Material
* Modified base database code and changed routes to matche entities and call the stored functions
* No AI tools were used
*/

// Get an instance of mysql we can use in the app
let mysql = require('mysql2')

// Create a 'connection pool' using the provided credentials
const pool = mysql.createPool({
    waitForConnections: true,
    connectionLimit   : 10,
    host              : 'classmysql.engr.oregonstate.edu',
    user              : '',
    password          : '',
    database          : ''
}).promise(); // This makes it so we can use async / await rather than callbacks

// Export it for use in our application
module.exports = pool;