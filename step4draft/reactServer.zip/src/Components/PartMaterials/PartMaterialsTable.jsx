import React from "react";
import PartMaterialsRow from "./PartMaterialsRow"
import CreatePartMaterialsForm from "./CreatePartMaterialsForm";
import { useState, useEffect } from "react";
function PartMaterialsTable({setRowToEdit, backendURL}){
    const [count, setCount] = useState(0);
    const refresh = () => {
        setCount(count+1);
            loadData();
    };

    const [partMaterials, setPartMaterials] = useState([]);
    useEffect(() => {
        loadData();
        }, []
    )
    const loadData = async () => {
        const response = await fetch(backendURL + '/partMaterials');
        const data = await response.json();
        setPartMaterials(data.partMaterials);
    }

    console.log(partMaterials)

    return (
        <div>                
            <table>
                <thead>
                    <tr>
                        <th>
                            Part Material ID
                        </th>
                        <th>
                            Material ID
                        </th>
                        <th>
                            Part ID
                        </th>
                        <th>
                            Options
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {partMaterials.map(partMaterial => <PartMaterialsRow 
                        refresh = {refresh}
                        backendURL = {backendURL}
                        partMaterial = {partMaterial}
                        partMaterialID = {partMaterial.partMaterialID}
                        Materials_materialID = {partMaterial.materials_materialID}
                        Parts_partID = {partMaterial.parts_partID}
                        setRowToEdit = {setRowToEdit}
                    /> )}
                </tbody>
            </table>
            <br/>
            <CreatePartMaterialsForm refresh={refresh} backendURL={backendURL}/>
        </div>

    )
}
export default PartMaterialsTable;