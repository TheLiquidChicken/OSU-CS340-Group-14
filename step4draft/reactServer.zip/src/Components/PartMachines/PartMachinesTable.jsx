import React from "react";
import PartMachinesRow from "./PartMachinesRow"
import CreatePartMachinesForm from "./CreatePartMachinesForm";
import { useState, useEffect } from "react";
function PartMachinesTable({setRowToEdit, backendURL}){
    //refreshes part machines
    const [count, setCount] = useState(0);
    const refresh = () => {
        setCount(count+1);
            loadData();
    };

    const [partMachines, setPartMaterials] = useState([]);
    useEffect(() => {
        loadData();
        }, []
    )
    const loadData = async () => {
        const response = await fetch(backendURL + '/partMachines');
        const data = await response.json();
        setPartMaterials(data.partMachines);
    }
    return (
        <div>
            <table>
                <thead>
                    <tr>
                        <th>
                            PartMachineID
                        </th>
                        <th>
                            MachineID
                        </th>
                        <th>
                            PartID
                        </th>
                        <th>
                            Options
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {partMachines.map(partMachine => <PartMachinesRow 
                        refresh={refresh}
                        partMachine = {partMachine}
                        partMachineID = {partMachine.partMachineID}
                        Machines_machineID = {partMachine.machines_machineID}
                        Parts_partID = {partMachine.parts_partID}
                        setRowToEdit = {setRowToEdit}
                        backendURL = {backendURL}
                    /> )}
                </tbody>
            </table>
            <br/>
            <CreatePartMachinesForm refresh={refresh} backendURL={backendURL}/>
        </div>
    )
}
export default PartMachinesTable;