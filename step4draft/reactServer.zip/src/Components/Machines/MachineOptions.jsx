import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function MachineOptions({backendURL, machine, setRowToEdit, refresh}){
    const deleteMachines = async () => {
        const thisMachine = machine;
        const response = await fetch(backendURL + `/machines/${thisMachine.machineID}`, {method: 'DELETE'});
        if(response.status === 204) {
            alert(`Deleted Machine with ID: ${thisMachine.machineID} Succesfully`);
            refresh();
        } else {
            alert(`No Machine Found with ID or Query Error: ${thisMachine.machineID}, status code = ${response.status}`);
        }
    }

    const editMachines = async (machines) => {
        setRowToEdit(machines);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deleteMachines}/> 

            <Link to="/editmachines"><CiEdit class="modify" onClick={() => editMachines(machine)}/></Link>
        </div>
    )
}
export default MachineOptions;