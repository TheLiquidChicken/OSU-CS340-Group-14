import {useState} from 'react';
import React from 'react';
    function editMaterialTypeForm ({rowToEdit, backendURL}) {
        const editMaterialType = async () => {
            const thisMaterialType = {materialTypeID:materialTypeID, materialTypeDescription:materialTypeDescription}
            const response = await fetch(backendURL + `/materialTypes/${rowToEdit.materialTypeID}`, {
                method: 'PUT',
                body: JSON.stringify(thisMaterialType),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 200) {
                alert(`Edited Material Type with ID: ${thisMaterialType.materialTypeID} Successfully`)
            } else {
                alert(`No Material Type Found or Query Error with Material Type ID: ${thisMaterialType.materialTypeID}, status code = ${response.status}`)
            }
        }
        
        const [materialTypeID, setMaterialTypeID] = useState(rowToEdit.materialTypeID);
        const [materialTypeDescription, setMaterialTypeDescription] = useState(rowToEdit.materialTypeDescription);

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Edit Material Type</legend>
            <label>Enter Material Type ID
                <input type="text" className="unit-input" value={materialTypeID}
                    onChange={e => setMaterialTypeID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Material Type Description
                <input type="text" className="unit-input" value={materialTypeDescription}
                    onChange={e => setMaterialTypeDescription(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            editMaterialType();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default editMaterialTypeForm;