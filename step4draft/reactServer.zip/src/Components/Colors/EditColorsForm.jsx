import {useState} from 'react';
import React from 'react';
    function editColorForm ({rowToEdit,backendURL}) {
        const editColor = async () => {
            const thisColor = {colorID:colorID, colorDescription:colorDescription}
            const response = await fetch(backendURL + `/colors/${rowToEdit.colorID}`, {
                method: 'PUT',
                body: JSON.stringify(thisColor),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 200) {
                alert(`Edited Color with ID: ${thisColor.colorID} Successfully`)
            } else {
                alert(`No Color Found or Query Error with Color ID: ${thisColor.colorID}, status code = ${response.status}`)
            }
        }
        
        const [colorID, setColorID] = useState(rowToEdit.colorID);
        const [colorDescription, setColorDescritpion] = useState(rowToEdit.colorDescription);

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Edit Color</legend>
            <label>Enter Color ID
                <input type="text" className="unit-input" value={colorID}
                    onChange={e => setColorID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Color Description
                <input type="text" className="unit-input" value={colorDescription}
                    onChange={e => setColorDescritpion(e.target.value)} />
            </label>
                    </fieldset>
                </form>
            <button onClick={e => {
            editColor();
            e.preventDefault();
        }}>Submit</button>
            </div>
        )
    }



export default editColorForm;