import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function MaterialOptions({backendURL, material, setRowToEdit, refresh}){
    const deleteMaterial = async () => {
        const thisMaterial = material;
        const response = await fetch(backendURL + `/materials/${thisMaterial.materialID}`, {method: 'DELETE'});
        if(response.status === 204) {
            alert(`Deleted Material with ID: ${thisMaterial.materialID} Succesfully`);
            refresh();
        } else {
            alert(`No Material Found with ID or Query Error: ${thisMaterial.materialID}, status code = ${response.status}`)
        }    }

    const editMaterial = async (materialTypes) => {
        setRowToEdit(materialTypes);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deleteMaterial}/> 

            <Link to="/editMaterials"><CiEdit class="modify" onClick={() => editMaterial(material)}/></Link>
        </div>
    )
}
export default MaterialOptions;