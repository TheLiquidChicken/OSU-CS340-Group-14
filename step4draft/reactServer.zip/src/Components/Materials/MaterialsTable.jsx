import React from "react";
import MaterialsRow from "./MaterialsRow"
import CreateMaterialsForm from "./CreateMaterialsForm";
import { useState, useEffect } from "react";
function MaterialsTable({setRowToEdit, backendURL}){

//refreshes materials
const [count, setCount] = useState(0);
const refresh = () => {
    setCount(count+1);
        loadData();
};

const [materials, setMaterials] = useState([]);
    useEffect(() => {
        loadData();
    }, []
)
    const loadData = async () => {
        const response = await fetch(backendURL + '/materials');
        const data = await response.json();
        setMaterials(data.materials);
    }
    return (
    <div>
        <table>
            <thead>
                <tr>
                    <th>
                        Material ID
                    </th>
                    <th>
                        Material Type ID
                    </th>
                    <th>
                        Color ID
                    </th>
                    <th>
                        Kilograms
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {materials.map(material => <MaterialsRow 
                    refresh={refresh}
                    backendURL = {backendURL}
                    material = {material}
                    materialID = {material.materialID}
                    MaterialTypes_materialTypeID = {material.MaterialTypes_materialTypeID}
                    Colors_colorID = {material.Colors_colorID}
                    kilograms = {material.kilograms}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
        <br/>
        <CreateMaterialsForm refresh = {refresh} backendURL={backendURL}/>
    </div>    
    )
}
export default MaterialsTable;