import {useState} from 'react';
import React from 'react';
    function createPartsForm ({backendURL, refresh}) {
        const createPart = async () => {
            const thisPart = {partName:partName, partPath:partPath, quantity:quantity, mass:mass, infillDensity:infillDensity, orders_orderID:orders_orderID} 
            const response = await fetch(backendURL + `/parts`, {
                method: 'POST',
                body: JSON.stringify(thisPart),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                const data = await response.json();
                alert(`Created Part Successfully with ID ${data[0]["@newID"]}`);
                refresh();
            } else {
                alert(`Query Error, status code = ${response.status}`)
            }
        }
        
        const [partID, setPartID] = useState();
        const [partName, setPartName] = useState();
        const [partPath, setPartPath] = useState();
        const [quantity, setQuantity] = useState();
        const [mass, setMass] = useState();
        const [infillDensity, setInfillDensity] = useState();
        const [orders_orderID, setOrders_orderID] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Part</legend>
            <br/>
            <label>Enter Part Name
                <input type="text" className="unit-input" value={partName}
                    onChange={e => setPartName(e.target.value)} />
            </label>
            <br/>
            <label>Enter Part File Path
                <input type="text" className="unit-input" value={partPath}
                    onChange={e => setPartPath(e.target.value)} />
            </label>
            <br/>
            <label>Enter Quantity
                <input type="number" className="unit-input" value={quantity}
                    onChange={e => setQuantity(e.target.value)} />
            </label>
            <br/>
            <label>Enter Part Mass
                <input type="number" className="unit-input" value={mass}
                    onChange={e => setMass(e.target.value)} />
            </label>
            <br/>
            <label>Enter Part Infill Density
                <input type="text" className="unit-input" value={infillDensity}
                    onChange={e => setInfillDensity(e.target.value)} />
            </label>
            <br/>
            <label>Enter Order ID
                <input type="text" className="unit-input" value={orders_orderID}
                    onChange={e => setOrders_orderID(e.target.value)} />
            </label>
            <br/>
                    </fieldset>
                    <button onClick={e => {
            createPart();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default createPartsForm;