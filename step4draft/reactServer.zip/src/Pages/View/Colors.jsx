import React from "react";
import ColorsTable from '/src/Components/Colors/ColorsTable'
import CreateColorsForm from "../../Components/Colors/CreateColorsForm";
import MaterialsTable from "../../Components/Materials/MaterialsTable";
import CreateMaterialsForm from "../../Components/Materials/CreateMaterialsForm";
import PartMaterialsTable from "../../Components/PartMaterials/PartMaterialsTable"
import CreatePartMaterialsForm from "../../Components/PartMaterials/CreatePartMaterialsForm";
import { useEffect, useState} from "react";
function Colors({backendURL, setRowToEdit}) {
    //refreshes the component and gets data again
    const [count, setCount] = useState(0);
    const refresh = () => {
        setCount(count+1);
        loadData();
    };

    const [colors, setColors] = useState([]);
    useEffect(() => {
        loadData();
    }, []
    )   
    const loadData = async () => {
        const response = await fetch(backendURL + '/colors');
        const data = await response.json();
        setColors(data.colors);
    }

    return (
        <>
            <h2>3Designs Colors</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update colors here!</p>
            </div>
            <div class="entityCategory">
                <ColorsTable refresh = {refresh} colors={colors} setRowToEdit={setRowToEdit} backendURL={backendURL}/>
                <br/>
                <CreateColorsForm refresh = {refresh} backendURL={backendURL}/>
            </div>
            <h3>Materials Combinations</h3>
            <p>Add types of materials and color combinations here</p>
            <div class="entityCategory">
                <MaterialsTable setRowToEdit={setRowToEdit} backendURL={backendURL}/>
            </div>
            <h3>Part Material Combinations</h3>
            <p>Assign Materials to parts here</p>
            <div class="entityCategory">
                <PartMaterialsTable setRowToEdit={setRowToEdit} backendURL={backendURL}/>

            </div>
        </>
    )
} export default Colors;