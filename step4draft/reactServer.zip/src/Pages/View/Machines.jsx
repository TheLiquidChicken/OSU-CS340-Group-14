import React from "react";
import MachinesTable from '/src/Components/Machines/MachinesTable.jsx'
import CreateMachineForm from "../../Components/Machines/CreateMachinesForm";
import { useEffect, useState} from "react";

import CreatePartMachinesForm from "../../Components/PartMachines/CreatePartMachinesForm";
import PartMachinesTable from "../../Components/PartMachines/PartMachinesTable";
function Machines({backendURL, setRowToEdit}) {
    //refreshes the component and gets data again
    const [count, setCount] = useState(0);
    const refresh = () => {
        setCount(count+1);
        loadData();
    };

    const [machines, setMachines] = useState([]);
    useEffect(() => {
        loadData();
    }, []
)
    const loadData = async () => {
        const response = await fetch(backendURL + '/machines');
        const data = await response.json();
        setMachines(data.machines);
    }

    return (
        <>
            <h2>3Designs Machines</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update machines here!</p>
            </div>
            <div class="entityCategory">
                <MachinesTable refresh = {refresh} machines={machines} backendURL={backendURL} setRowToEdit={setRowToEdit}/>
                <br/>
                <CreateMachineForm refresh = {refresh} backendURL={backendURL}/>
            </div>
            <h3>Part Machine Assignments</h3>
            <p>Assign Parts to Machines here</p>
            <div class="entityCategory">
                <PartMachinesTable backendURL={backendURL} setRowToEdit={setRowToEdit}/>
                <br/>
                <CreatePartMachinesForm backendURL={backendURL}/>
            </div>
        </>
    )
} export default Machines;