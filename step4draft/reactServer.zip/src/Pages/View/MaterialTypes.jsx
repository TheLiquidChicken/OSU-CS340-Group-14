import React from "react";
import MaterialTypesTable from "../../Components/MaterialTypes/MaterialTypesTable";
import CreateMaterialTypeForm from "../../Components/MaterialTypes/CreateMaterialTypesForm";
import MaterialsTable from "../../Components/Materials/MaterialsTable";
import CreateMaterialsForm from "../../Components/Materials/CreateMaterialsForm";
import PartMaterialsTable from "../../Components/PartMaterials/PartMaterialsTable";
import CreatePartMaterialsForm from "../../Components/PartMachines/CreatePartMachinesForm";
import { useEffect, useState} from "react";
function MaterialTypes({backendURL, setRowToEdit}) {
    //refreshes the component and gets data again
    const [count, setCount] = useState(0);
    const refresh = () => {
        setCount(count+1);
        loadData();
    };

    const [materialTypes, setMaterialTypes] = useState([]);
    useEffect(() => {
        loadData();
    }, []
    )   
    const loadData = async () => {
        const response = await fetch(backendURL + '/materialTypes');
        const data = await response.json();
        setMaterialTypes(data.materialTypes);
    }
    return (
        <>
            <h2>3Designs MaterialTypes</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update material types here!</p>
            </div>
            <div class="entityCategory">
                <MaterialTypesTable refresh = {refresh} materialTypes={materialTypes} setRowToEdit={setRowToEdit} backendURL={backendURL}/>
                <br/>
                <CreateMaterialTypeForm refresh = {refresh} backendURL={backendURL}/>
            </div>

            <h3>Materials Combinations</h3>
            <p>Add types of materials and color combinations here</p>
            <div class="entityCategory">
                <MaterialsTable setRowToEdit={setRowToEdit} backendURL={backendURL}/>
            </div>

            <h3>Part Material Combinations</h3>
            <p>Assign Materials to parts here</p>
            <div class="entityCategory">
                <PartMaterialsTable setRowToEdit={setRowToEdit} backendURL={backendURL}/>
            </div>
        </>
    )
} export default MaterialTypes;