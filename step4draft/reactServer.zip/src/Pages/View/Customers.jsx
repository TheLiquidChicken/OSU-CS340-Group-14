import React from "react";
import CustomersTable from '/src/Components/Customers/CustomersTable'
import CreateCustomersForm from "../../Components/Customers/CreateCustomersForm";
import { useEffect, useState} from "react";
function Customers({backendURL, setRowToEdit}) {
    //refreshes the component and gets data again
    const [count, setCount] = useState(0);
    const refresh = () => {
        setCount(count+1);
        loadData();
    };

    const [customers, setCustomers] = useState([]);
    useEffect(() => {
        loadData();
    }, []
)

    const loadData = async () => {
        const response = await fetch(backendURL + '/customers');
        const data = await response.json();
        setCustomers(data.customers);
    }

    return (
        <>
            <h2>3Designs Customers</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update customers here!</p>
            </div>
            <div class="entityCategory">
                <CustomersTable refresh = {refresh} backendURL={backendURL} customers={customers} setRowToEdit={setRowToEdit}/>
                <br/>
                <CreateCustomersForm refresh = {refresh} backendURL={backendURL}/>
            </div>
        </>
    )
} export default Customers;