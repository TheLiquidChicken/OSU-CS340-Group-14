import React from "react";
import PartsTable from '/src/Components/Parts/PartsTable';
import CreatePartsForm from "../../Components/Parts/CreatePartsForm";
import { useEffect, useState} from "react";
import PartMachinesTable from "../../Components/PartMachines/PartMachinesTable";
import CreatePartMachinesForm from "../../Components/PartMachines/CreatePartMachinesForm";
import PartMaterialsTable from "../../Components/PartMaterials/PartMaterialsTable";
import CreatePartMaterialsForm from "../../Components/PartMaterials/CreatePartMaterialsForm";
function Parts({backendURL, setRowToEdit}) {
    //refreshes the component and gets data again
    const [count, setCount] = useState(0);
    const refresh = () => {
        setCount(count+1);
        loadData();
    };
    
    const [parts, setParts] = useState([]);
    useEffect(() => {
        loadData();
    }, []
    )   
    const loadData = async () => {
        const response = await fetch(backendURL + '/parts');
        const data = await response.json();
        setParts(data.parts);
    }
    return (
        <>
            <h2>3Designs Parts</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update parts here!</p>
            </div>
            <div class="entityCategory">
                <PartsTable refresh = {refresh} parts={parts} setRowToEdit={setRowToEdit} backendURL={backendURL}/>
                <br/>
                <CreatePartsForm refresh = {refresh} backendURL={backendURL}/>
            </div>

            <h3>Part Machine Assignments</h3>
            <p>Assign Parts to Machines here</p>
            <div class="entityCategory">
                <PartMachinesTable setRowToEdit={setRowToEdit} backendURL={backendURL}/>
            </div>

            <h3>Part Material Combinations</h3>
            <p>Assign Materials to parts here</p>
            <div class="entityCategory">
                <PartMaterialsTable setRowToEdit={setRowToEdit} backendURL={backendURL}/>
            </div>
        </>
    )
} export default Parts;