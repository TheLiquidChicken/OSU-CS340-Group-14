import React from "react";
function Home({backendURL}) {
    const resetDatabase = async () => {
        const response = await fetch(backendURL + `/reset`, {
                method: 'POST',
                body: JSON.stringify(),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                alert(`Reset Successfully`)
            } else {
                alert(`Query Error, status code = ${response.status}`)
            }
    }
    return (
        <>
            <div className="homepageDescription">
                <p>Add, remove, and update customers, materials, colors, and orders here!</p>
                <br/>
                <p>
                    Press the button below to reset the database!
                </p>
                <button onClick={resetDatabase}>
                    Reset
                </button>
            </div>
        </>
    )
} export default Home;
//acquired from https://canvas.oregonstate.edu/courses/2042369/pages/exploration-web-application-technology-2?module_item_id=26640188