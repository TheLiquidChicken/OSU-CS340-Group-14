import React from "react";
import CustomersTable from '/src/Components/Customers/CustomersTable'
import CreateCustomersForm from "../../Components/Customers/CreateCustomersForm";
import { useEffect, useState} from "react";
function Customers({backendURL, setRowToEdit}) {
    const [customers, setCustomers] = useState([]);
    useEffect(() => {
        loadCustomers();
    }, []
)
    const loadCustomers = async () => {
        const response = await fetch(backendURL + '/customers');
        const data = await response.json();
        setCustomers(data.customers);
    }

    return (
        <>
            <h2>3Designs Customers</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update customers here!</p>
            </div>
            <div class="entityCategory">
                <CustomersTable backendURL={backendURL} customers={customers} setRowToEdit={setRowToEdit}/>
                <br/>
                <CreateCustomersForm backendURL={backendURL}/>
            </div>
        </>
    )
} export default Customers;