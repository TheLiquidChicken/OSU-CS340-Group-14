import React from "react";
import OrdersTable from '/src/Components/Orders/OrdersTable';
import CreateOrderForm from "../../Components/Orders/CreateOrdersForm";
import { useEffect, useState} from "react";
function Orders({backendURL, setRowToEdit}) {
    const [orders, setOrders] = useState([]);
    useEffect(() => {
        loadOrders();
    }, []
    )   
    const loadOrders = async () => {
        const response = await fetch(backendURL + '/orders');
        const data = await response.json();
        setOrders(data.orders);
    }
    return (
        <>
            <h2>3Designs Orders</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update orders here!</p>
            </div>
            <div class="entityCategory">
                <OrdersTable orders={orders} setRowToEdit={setRowToEdit} backendURL={backendURL}/>
                <br/>
                <CreateOrderForm backendURL={backendURL}/>
            </div>
        </>
    )
} export default Orders;