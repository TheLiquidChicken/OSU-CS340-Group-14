import React from "react";
import MachinesTable from '/src/Components/Machines/MachinesTable.jsx'
import CreateMachineForm from "../../Components/Machines/CreateMachinesForm";
import { useEffect, useState} from "react";

import CreatePartMachinesForm from "../../Components/PartMachines/CreatePartMachinesForm";
import PartMachinesTable from "../../Components/PartMachines/PartMachinesTable";
function Machines({backendURL, setRowToEdit}) {
    const [machines, setMachines] = useState([]);
    useEffect(() => {
        loadMachines();
    }, []
)
    const loadMachines = async () => {
        const response = await fetch(backendURL + '/machines');
        const data = await response.json();
        setMachines(data.machines);
    }

    return (
        <>
            <h2>3Designs Machines</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update machines here!</p>
            </div>
            <div class="entityCategory">
                <MachinesTable machines={machines} backendURL={backendURL} setRowToEdit={setRowToEdit}/>
                <br/>
                <CreateMachineForm backendURL={backendURL}/>
            </div>
            <h3>Part Machine Assignments</h3>
            <p>Assign Parts to Machines here</p>
            <div class="entityCategory">
                <PartMachinesTable backendURL={backendURL} setRowToEdit={setRowToEdit}/>
                <br/>
                <CreatePartMachinesForm backendURL={backendURL}/>
            </div>
        </>
    )
} export default Machines;