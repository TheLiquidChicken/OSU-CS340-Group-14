import React from "react";
import MaterialsRow from "./MaterialsRow"
import { useState, useEffect } from "react";
function MaterialsTable({setRowToEdit, backendURL}){
    const [materials, setMaterials] = useState([]);
    useEffect(() => {
        loadMaterials();
    }, []
)
    const loadMaterials = async () => {
        const response = await fetch(backendURL + '/materials');
        const data = await response.json();
        setMaterials(data.materials);
    }
    return (
        <table>
            <thead>
                <tr>
                    <th>
                        Material ID
                    </th>
                    <th>
                        Material Type ID
                    </th>
                    <th>
                        Color ID
                    </th>
                    <th>
                        Kilograms
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {materials.map(material => <MaterialsRow 
                    backendURL = {backendURL}
                    material = {material}
                    materialID = {material.materialID}
                    MaterialTypes_materialTypeID = {material.MaterialTypes_materialTypeID}
                    Colors_colorID = {material.Colors_colorID}
                    kilograms = {material.kilograms}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
    )
}
export default MaterialsTable;