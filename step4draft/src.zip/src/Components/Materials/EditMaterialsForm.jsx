import {useState} from 'react';
import React from 'react';
    function editMaterialsForm ({rowToEdit, backendURL}) {
        const editMaterial = async () => {
            const thisMaterial = {materialID:rowToEdit.materialID, MaterialTypes_materialTypeID:MaterialTypes_materialTypeID, Colors_colorID:Colors_colorID, kilograms:kilograms}
            const response = await fetch(backendURL + `/materials/${thisMaterial.materialID}`, {
                method: 'PUT',
                body: JSON.stringify(thisMaterial),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 200) {
                alert(`Edited Material with ID: ${thisMaterial.materialID} Successfully`)
            } else {
                alert(`No Material Found or Query Error with Material ID: ${thisMaterial.materialID}, status code = ${response.status}`)
            }
        }
        
        const [materialID, setMaterialID] = useState(rowToEdit.materialID);
        const [MaterialTypes_materialTypeID, setMaterialTypeID] = useState(rowToEdit.MaterialTypes_materialTypeID);
        const [Colors_colorID, setColorID] = useState(rowToEdit.Colors_colorID);
        const [kilograms, setKilograms] = useState(rowToEdit.kilograms);

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Edit Materials with ID: {materialID}</legend>
            <label>Enter Material Type ID
                <input type="text" className="unit-input" value={MaterialTypes_materialTypeID}
                    onChange={e => setMaterialTypeID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Color ID
                <input type="text" className="unit-input" value={Colors_colorID}
                    onChange={e => setColorID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Kilograms
                <input type="text" className="unit-input" value={kilograms}
                    onChange={e => setKilograms(e.target.value)} />
            </label>
                    </fieldset>
                </form>
                <button onClick={e => {
            editMaterial();
            e.preventDefault();
        }}>Submit</button>
            </div>
        )
    }



export default editMaterialsForm;