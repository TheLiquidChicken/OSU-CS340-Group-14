import React from "react";
import MaterialTypesRow from "./MaterialTypesRow"
import MaterialTypes from "../../Pages/View/MaterialTypes";
function MaterialTypesTable({materialTypes, setRowToEdit, backendURL}){

    return (
        <table>
            <thead>
                <tr>
                    <th>
                        Material Type ID
                    </th>
                    <th>
                        Material Type Description
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {materialTypes.map(materialType => <MaterialTypesRow 
                    backendURL = {backendURL}
                    materialType = {materialType}
                    materialTypeID = {materialType.materialTypeID}
                    materialTypeDescription = {materialType.materialTypeDescription}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
    )
}
export default MaterialTypesTable;