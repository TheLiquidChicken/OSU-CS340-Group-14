import {useState} from 'react';
import React from 'react';
    function createMaterialTypeForm ({backendURL}) {
        const createMaterialType = async () => {
            const thisMaterialType = {materialTypeDescription:materialTypeDescription} 
            const response = await fetch(backendURL + `/materialTypes`, {
                method: 'POST',
                body: JSON.stringify(thisMaterialType),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                alert(`Created Material Type Successfully`)
            } else {
                alert(`Query Error, status code = ${response.status}`)
            }
        }
        
        const [materialTypeID, setMaterialTypeID] = useState();
        const [materialTypeDescription, setMaterialTypeDescription] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Material Type</legend>
            <label>Enter Material Type ID
                <input type="text" className="unit-input" value={materialTypeID}
                    onChange={e => setMaterialTypeID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Material Type Description
                <input type="text" className="unit-input" value={materialTypeDescription}
                    onChange={e => setMaterialTypeDescription(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            createMaterialType();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default createMaterialTypeForm;