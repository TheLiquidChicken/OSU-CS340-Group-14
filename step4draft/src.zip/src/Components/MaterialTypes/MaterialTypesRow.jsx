import React from "react";
import MaterialTypesOptions from "./MaterialTypesOptions.jsx";
function MaterialTypesRow({materialType, materialTypeID, materialTypeDescription, setRowToEdit, backendURL}) {
    return(
        <tr>
            <td>
                {materialTypeID}
            </td>
            <td>
                {materialTypeDescription}
            </td>
            <td>
                <MaterialTypesOptions backendURL={backendURL} materialType={materialType} setRowToEdit={setRowToEdit}/>
            </td>
            
        </tr>
    )
}
export default MaterialTypesRow;