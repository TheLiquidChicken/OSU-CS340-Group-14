import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function MaterialTypeOptions({materialType, setRowToEdit, backendURL}){
    const deleteMaterialTypes = async () => {
        const thisMaterialType = materialType;
        const response = await fetch(backendURL + `/materialTypes/${thisMaterialType.materialTypeID}`, {method: 'DELETE'});
        if(response.status === 204) {
            alert(`Deleted Material Type with ID: ${thisMaterialType.materialTypeID} Succesfully`)
        } else {
            alert(`No Material Type Found with ID or Query Error: ${thisMaterialType.materialTypeID}, status code = ${response.status}`)
        }
    }

    const editMaterialTypes = async (materialTypes) => {
        setRowToEdit(materialTypes);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deleteMaterialTypes}/> 

            <Link to="/editmaterialTypes"><CiEdit class="modify" onClick={() => editMaterialTypes(materialType)}/></Link>
        </div>
    )
}
export default MaterialTypeOptions;