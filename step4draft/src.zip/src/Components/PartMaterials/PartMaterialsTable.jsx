import React from "react";
import PartMaterialsRow from "./PartMaterialsRow"
import { useState, useEffect } from "react";
function PartMaterialsTable({setRowToEdit, backendURL}){
    const [partMaterials, setPartMaterials] = useState([]);
    useEffect(() => {
        loadPartMaterials();
        }, []
    )
    const loadPartMaterials = async () => {
        const response = await fetch(backendURL + '/partMaterials');
        const data = await response.json();
        setPartMaterials(data.partMaterials);
    }

    return (
        <table>
            <thead>
                <tr>
                    <th>
                        Part Material ID
                    </th>
                    <th>
                        Material ID
                    </th>
                    <th>
                        Part ID
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {partMaterials.map(partMaterial => <PartMaterialsRow 
                    backendURL = {backendURL}
                    partMaterial = {partMaterial}
                    partMaterialID = {partMaterial.partMaterialID}
                    Materials_materialID = {partMaterial.Materials_materialID}
                    Parts_partID = {partMaterial.Parts_partID}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
    )
}
export default PartMaterialsTable;