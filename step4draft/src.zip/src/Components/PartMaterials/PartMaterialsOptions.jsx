import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function PartMaterialsOptions({partMaterial, setRowToEdit, backendURL}){
    const deletePartMaterial = async () => {
        const thisPartMaterial = partMaterial;
        const response = await fetch(backendURL + `/partMaterials/${thisPartMaterial.partMaterialID}`, {method: 'DELETE'});
        if(response.status === 204) {
            alert(`Deleted Part Machine with ID: ${thisPartMaterial.partMaterialID} Succesfully`)
        } else {
            alert(`No Part Machine Found with ID or Query Error: ${thisPartMaterial.partMaterialID}, status code = ${response.status}`)
        }
    }

    const editPartMaterial = async (materialTypes) => {
        setRowToEdit(materialTypes);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deletePartMaterial}/> 

            <Link to="/editPartMaterial"><CiEdit class="modify" onClick={() => editPartMaterial(partMaterial)}/></Link>
        </div>
    )
}
export default PartMaterialsOptions;