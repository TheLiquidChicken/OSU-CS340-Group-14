import {useState} from 'react';
import React from 'react';
    function CreatePartMaterialsForm ({backendURL}) {
        const createPartMaterial = async () => {
            const thisPartMaterial = {Materials_materialID:Materials_materialID, Parts_partID:Parts_partID} 
            const response = await fetch(backendURL + `/partMaterials`, {
                method: 'POST',
                body: JSON.stringify(thisPartMaterial),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                alert(`Created Part Material Successfully`)
            } else {
                alert(`Query Error, status code = ${response.status}`)
            }
        }
        
        const [Materials_materialID, setMaterialID] = useState();
        const [Parts_partID, setPartID] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Part Material</legend>
            <label>Enter Material ID
                <input type="text" className="unit-input" value={Materials_materialID}
                    onChange={e => setMaterialID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Part ID
                <input type="text" className="unit-input" value={Parts_partID}
                    onChange={e => setPartID(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            createPartMaterial();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default CreatePartMaterialsForm;