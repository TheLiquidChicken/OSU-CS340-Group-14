import {useState} from 'react';
import React from 'react';
    function createPartMachinesForm ({backendURL}) {
        const createPartMachine = async () => {
            const thisPartMachine = {Machines_machineID:Machines_machineID, Parts_partID:Parts_partID} 
            const response = await fetch(backendURL + `/partMachines`, {
                method: 'POST',
                body: JSON.stringify(thisPartMachine),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                alert(`Created Part Machine Successfully`)
            } else {
                alert(`Query Error, status code = ${response.status}`)
            }
        }
        
        const [Machines_machineID, setMachineID] = useState();
        const [Parts_partID, setPartID] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create PartMaterial</legend>
            <label>Enter MachineID
                <input type="text" className="unit-input" value={Machines_machineID}
                    onChange={e => setMachineID(e.target.value)} />
            </label>
            <br/>
            <label>Enter PartID
                <input type="text" className="unit-input" value={Parts_partID}
                    onChange={e => setPartID(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            createPartMachine();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default createPartMachinesForm;