import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function PartMachinesOptions({partMachine, setRowToEdit, backendURL}){
    const deletePartMachine = async () => {        
        const thisPartMachine = partMachine;
        const response = await fetch(backendURL + `/partMachines/${thisPartMachine.partMachineID}`, {method: 'DELETE'});
        if(response.status === 204) {
            alert(`Deleted Part Machine with ID: ${thisPartMachine.partMachineID} Succesfully`)
        } else {
            alert(`No Part Machine Found with ID or Query Error: ${thisPartMachine.partMachineID}, status code = ${response.status}`)
        }
    }

    const editPartMachine = async (materialTypes) => {
        setRowToEdit(materialTypes);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deletePartMachine}/> 

            <Link to="/editPartMachine"><CiEdit class="modify" onClick={() => editPartMachine(partMachine)}/></Link>
        </div>
    )
}
export default PartMachinesOptions;