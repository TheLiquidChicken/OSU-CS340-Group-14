import React from "react";
import PartMachinesRow from "./PartMachinesRow"
import { useState, useEffect } from "react";
function PartMachinesTable({setRowToEdit, backendURL}){
    const [partMachines, setPartMaterials] = useState([]);
    useEffect(() => {
        loadPartMachines();
        }, []
    )
    const loadPartMachines = async () => {
        const response = await fetch(backendURL + '/partMachines');
        const data = await response.json();
        setPartMaterials(data.partMachines);
    }
    return (
        <table>
            <thead>
                <tr>
                    <th>
                        PartMachineID
                    </th>
                    <th>
                        MachineID
                    </th>
                    <th>
                        PartID
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {partMachines.map(partMachine => <PartMachinesRow 
                    partMachine = {partMachine}
                    partMachineID = {partMachine.partMachineID}
                    Machines_machineID = {partMachine.Machines_machineID}
                    Parts_partID = {partMachine.Parts_partID}
                    setRowToEdit = {setRowToEdit}
                    backendURL = {backendURL}
                /> )}
            </tbody>
        </table>
    )
}
export default PartMachinesTable;