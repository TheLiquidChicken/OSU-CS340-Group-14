import {useState} from 'react';
import React from 'react';
    function createOrderForm ({backendURL}) {
        const createOrder = async () => {
            const thisOrder = {revenue:revenue, date:date, customers_customerID:customers_customerID} 
            const response = await fetch(backendURL + `/orders`, {
                method: 'POST',
                body: JSON.stringify(thisOrder),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                alert(`Created Order Successfully`)
            } else {
                alert(`Query Error, status code = ${response.status}`)
            }
        }
        
        const [revenue, setRevenue] = useState();
        const [date, setDate] = useState();
        const [customers_customerID, setCustomers_customerID] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Order</legend>
            <label>Enter Revenue
                <input type="number" className="unit-input" value={revenue}
                    onChange={e => setRevenue(e.target.value)} />
            </label>
            <br/>
            <label>Enter Date
                <input type="date" className="unit-input" value={date}
                    onChange={e => setDate(e.target.value)} />
            </label>
            <br/>
            <label>Enter Customer ID
                <input type="text" className="unit-input" value={customers_customerID}
                    onChange={e => setCustomers_customerID(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            createOrder();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default createOrderForm;