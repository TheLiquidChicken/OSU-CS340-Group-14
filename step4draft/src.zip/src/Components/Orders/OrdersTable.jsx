import React from "react";
import OrdersRow from "./OrdersRow"
function OrdersTable({orders, setRowToEdit, backendURL}){

    return (
        <table>
            <thead>
                <tr>
                    <th>
                        Order ID
                    </th>
                    <th>
                        Revenue
                    </th>
                    <th>
                        Date
                    </th>
                    <th>
                        CustomerID
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {orders.map(order => <OrdersRow 
                    backendURL = {backendURL}
                    setRowToEdit = {setRowToEdit}
                    order = {order}
                    orderID = {order.orderID}
                    revenue = {order.revenue}
                    date = {order.date}
                    customers_customerID = {order.customers_customerID}
                /> )}
            </tbody>
        </table>
    )
}
export default OrdersTable;