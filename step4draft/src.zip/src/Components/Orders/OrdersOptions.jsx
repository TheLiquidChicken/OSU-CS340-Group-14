import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function OrderOptions({order, setRowToEdit, backendURL}){
    const deleteOrders = async () => {
        const thisOrder = order;
        const response = await fetch(backendURL + `/orders/${thisOrder.orderID}`, {method: 'DELETE'});
        if(response.status === 204) {
            alert(`Deleted Order with ID: ${thisOrder.orderID} Succesfully`)
        } else {
            alert(`No Order Found with ID or Query Error: ${thisOrder.orderID}, status code = ${response.status}`)
        }
    }

    const editOrders = async (orders) => {
        setRowToEdit(orders);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deleteOrders}/> 

            <Link to="/editorders"><CiEdit class="modify" onClick={() => editOrders(order)}/></Link>
        </div>
    )
}
export default OrderOptions;