import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function PartsOptions({part, setRowToEdit, backendURL}){
    const deletePart = async () => {
        const thisPart = part;
        const response = await fetch(backendURL + `/parts/${thisPart.partID}`, {method: 'DELETE'});
        if(response.status === 204) {
            alert(`Deleted Part with ID: ${thisPart.partID} Succesfully`)
        } else {
            alert(`No Part Found with ID or Query Error: ${thisPart.partID}, status code = ${response.status}`)
        }
    }

    const editPart = async (customerToEdit)=> {
        setRowToEdit(customerToEdit);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deletePart}/> 

            <Link to="/editparts"><CiEdit class="modify" onClick={() => editPart(part)}/></Link>
        </div>
    )
}
export default PartsOptions;