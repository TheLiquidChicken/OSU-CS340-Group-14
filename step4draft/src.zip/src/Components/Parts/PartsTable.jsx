import React from "react";
import PartsRow from "./PartsRow"
import Parts from "../../Pages/View/Parts";
function PartsTable({parts, setRowToEdit, backendURL}){

    return (
        <table>
            <thead>
                <tr>
                    <th>
                        Part ID
                    </th>
                    <th>
                        Part Name
                    </th>
                    <th>
                        Part File Path
                    </th>
                    <th>
                        Quantity
                    </th>
                    <th>
                        Mass
                    </th>
                    <th>
                        Infill Density
                    </th>
                    <th>
                        Order ID
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {parts.map(part => <PartsRow
                                                         setRowToEdit = {setRowToEdit}
                                                         backendURL = {backendURL}
                                                         part = {part}
                                                         partID = {part.partID}
                                                         partName = {part.partName}
                                                         partPath = {part.partPath}
                                                         quantity = {part.quantity}
                                                         mass = {part.mass}
                                                         infillDensity = {part.infillDensity}
                                                         orders_orderID = {part.orders_orderID}

                /> )}
            </tbody>
        </table>
    )
}
export default PartsTable;