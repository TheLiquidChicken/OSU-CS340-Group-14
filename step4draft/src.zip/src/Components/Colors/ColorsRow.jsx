import React from "react";
import ColorsOptions from "./ColorsOptions.jsx";
function ColorsRow({color, colorID, colorDescription, setRowToEdit, backendURL}) {

    return(
        <tr>
            <td>
                {colorID}
            </td>
            <td>
                {colorDescription}
            </td>
            <td>
                <ColorsOptions color={color} setRowToEdit={setRowToEdit} backendURL={backendURL}/>
            </td>
            
        </tr>
    )
}
export default ColorsRow;