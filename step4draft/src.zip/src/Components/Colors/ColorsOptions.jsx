import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function ColorsOptions({color, setRowToEdit, backendURL}){
    const deleteColor = async () => {
        const thisColor = color;
        const response = await fetch(backendURL + `/colors/${thisColor.colorID}`, {method: 'DELETE'});
        if(response.status === 204) {
            alert(`Deleted Color with ID: ${thisColor.colorID} Succesfully`)
        } else {
            alert(`No Color Found with ID or Query Error: ${thisColor.colorID}, status code = ${response.status}`)
        }
    }

    const editColor = async (colorToEdit)=> {
        setRowToEdit(colorToEdit);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deleteColor}/> 

            <Link to="/editcolors"><CiEdit class="modify" onClick={() => editColor(color)}/></Link>
        </div>
    )
}
export default ColorsOptions;