import {useState} from 'react';
import React from 'react';
    function createColorsForm ({backendURL}) {
        const createColor = async () => {
            const thisColor = {colorDescription:colorDescription} 
            const response = await fetch(backendURL + `/colors`, {
                method: 'POST',
                body: JSON.stringify(thisColor),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                alert(`Created Color Successfully`)
            } else {
                alert(`Query Error, status code = ${response.status}`)
            }
        }
        
        const [colorID, setColorID] = useState();
        const [colorDescription, setColorDescritpion] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Color</legend>
            <label>Enter Color ID
                <input type="text" className="unit-input" value={colorID}
                    onChange={e => setColorID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Color Description
                <input type="text" className="unit-input" value={colorDescription}
                    onChange={e => setColorDescritpion(e.target.value)} />
            </label>
                    </fieldset>
                </form>
            <button onClick={e => {
            createColor();
            e.preventDefault();
        }}>Submit</button>
            </div>
        )
    }



export default createColorsForm;