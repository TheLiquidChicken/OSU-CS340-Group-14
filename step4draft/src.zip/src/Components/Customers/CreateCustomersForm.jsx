import {useState} from 'react';
import React from 'react';
    function CreateCustomerForm ({backendURL}) {
        const createCustomer = async () => {
            const thisCustomer = {email:email, phoneNumber:phoneNumber, primaryContact:primaryContact, address:address}
            const response = await fetch(backendURL + `/customers`, {
                method: 'POST',
                body: JSON.stringify(thisCustomer),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                alert(`Created Customer Successfully`)
            } else {
                alert(`Query Error, status code = ${response.status}`)
            }
        }
        
        const [email, setEmail] = useState();
        const [phoneNumber, setPhoneNumber] = useState();
        const [primaryContact, setPrimaryContact] = useState();
        const [address, setAddress] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Customer</legend>
            <label>Enter Email
                <input type="text" className="unit-input" value={email}
                    onChange={e => setEmail(e.target.value)} />
            </label>
            <br/>
            <label>Enter Phone Number
                <input type="text" className="unit-input" value={phoneNumber}
                    onChange={e => setPhoneNumber(e.target.value)} />
            </label>
            <br/>
            <label>Enter Primary Contact
                <input type="text" className="unit-input" value={primaryContact}
                    onChange={e => setPrimaryContact(e.target.value)} />
            </label>
            <br/>
            <label>Enter Address
                <input type="text" className="unit-input" value={address}
                    onChange={e => setAddress(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            createCustomer();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default CreateCustomerForm;