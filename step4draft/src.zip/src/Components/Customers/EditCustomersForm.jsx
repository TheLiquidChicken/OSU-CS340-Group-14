import {useState} from 'react';
import React from 'react';
    function editCustomerForm ({backendURL, rowToEdit}) {
        const editCustomer = async () => {
            const thisCustomer = {customerID:rowToEdit.customerID, email:email, phoneNumber:phoneNumber, primaryContact:primaryContact, address:address}
            const response = await fetch(backendURL + `/customers/${thisCustomer.customerID}`, {
                method: 'PUT',
                body: JSON.stringify(thisCustomer),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 200) {
                alert(`Edited Customer with ID: ${thisCustomer} Successfully`)
            } else {
                alert(`No Customer Found or Query Error with Customer ID: ${thisCustomer.customerID}, status code = ${response.status}`)
            }
        }
        
        const [email, setEmail] = useState(rowToEdit.email);
        const [phoneNumber, setPhoneNumber] = useState(rowToEdit.phoneNumber);
        const [primaryContact, setPrimaryContact] = useState(rowToEdit.primaryContact);
        const [address, setAddress] = useState(rowToEdit.address);

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Edit Customer with ID: {rowToEdit.customerID}</legend>
            <label>Enter Email
                <input type="text" className="unit-input" value={email}
                    onChange={e => setEmail(e.target.value)} />
            </label>
            <br/>
            <label>Enter Phone Number
                <input type="text" className="unit-input" value={phoneNumber}
                    onChange={e => setPhoneNumber(e.target.value)} />
            </label>
            <br/>
            <label>Enter Primary Contact
                <input type="text" className="unit-input" value={primaryContact}
                    onChange={e => setPrimaryContact(e.target.value)} />
            </label>
            <br/>
            <br/>
            <label>Enter Address
                <input type="text" className="unit-input" value={address}
                    onChange={e => setAddress(e.target.value)} />
            </label>
            <br/>
                    </fieldset>
                    <button onClick={e => {
            editCustomer();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default editCustomerForm;