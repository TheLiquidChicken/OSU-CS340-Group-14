import React from "react";
import Options from "./CustomersOptions.jsx";
import CustomersOptions from "./CustomersOptions.jsx";
function CustomersRow({setRowToEdit, backendURL, customer, customerID, email, phoneNumber, primaryContact, address}) {

    return(
        <tr>
            <td>
                {customerID}
            </td>
            <td>
                {email}
            </td>
            <td>
                {phoneNumber}
            </td>
            <td>
                {primaryContact}
            </td>
            <td>
                {address}
            </td>
            <td>
                <CustomersOptions backendURL={backendURL} customer={customer} setRowToEdit={setRowToEdit}/>
            </td>
            
        </tr>
    )
}
export default CustomersRow;