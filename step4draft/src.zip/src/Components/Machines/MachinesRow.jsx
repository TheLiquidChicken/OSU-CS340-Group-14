import React from "react";
import MachineOptions from "./MachineOptions.jsx";
function MachinesRow({backendURL, machine, machineID, machineDescription, lastServiceDate, setRowToEdit}) {

    return(
        <tr>
            <td>
                {machineID}
            </td>
            <td>
                {machineDescription}
            </td>
            <td>
                {lastServiceDate}
            </td>
            <td>
                <MachineOptions machine={machine} setRowToEdit={setRowToEdit} backendURL={backendURL}/>
            </td>
            
        </tr>
    )
}
export default MachinesRow;