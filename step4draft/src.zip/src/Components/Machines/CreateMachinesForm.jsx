import {useState} from 'react';
import React from 'react';
    function createMachineForm ({backendURL}) {
        const createMachine = async () => {
            console.log('Edit Machine Executed')
            const thisMachine = {machineDescription:machineDescription, lastServiceDate:lastServiceDate}
            const response = await fetch(backendURL + `/machines`, {
                method: 'POST',
                body: JSON.stringify(thisMachine),
                headers: { 'Content-Type': 'application/json'}});
            if(response.status === 201) {
                alert(`Created Machine Successfully`)
            } else {
                alert(`Query Error, status code = ${response.status}`)
            }
        }
        
        const [machineDescription, setMachineDescription] = useState();
        const [lastServiceDate, setLastServiceDate] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Order</legend>
            <label>Enter Machine Description
                <input type="text" className="unit-input" value={machineDescription}
                    onChange={e => setRevenue(e.target.value)} />
            </label>
            <br/>
            <label>Enter Last Service Date
                <input type="date" className="unit-input" value={lastServiceDate}
                    onChange={e => setLastServiceDate(e.target.value)} />
            </label>
            <br/>
                    </fieldset>
                    <button onClick={e => {
            createMachine();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default createMachineForm;