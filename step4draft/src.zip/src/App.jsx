import './App.css';
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { useState} from 'react';
// Pages
import Home from './Pages/Home';
import Customers from './Pages/View/Customers';
import EditCustomers from './Pages/Edit/EditCustomers';
import Colors from './Pages/View/Colors';
import EditColors from './Pages/Edit/EditColors';
import MaterialTypes from './Pages/View/MaterialTypes';
import EditMaterialTypes from './Pages/Edit/EditMaterialTypes';
import Parts from './Pages/View/Parts';
import EditParts from './Pages/Edit/EditParts';
import Orders from './Pages/View/Orders';
import EditOrders from './Pages/Edit/EditOrders';
import Machines from './Pages/View/Machines';
import EditMachines from './Pages/Edit/EditMachines';
import EditMaterials from './Pages/Edit/EditMaterials';
import EditPartMachine from './Pages/Edit/EditPartMachine';
import EditPartMaterials from './Pages/Edit/EditPartMaterials'

// Components
import Navigation from './Components/Navigation';

// Define the backend port and URL for API requests
const backendPort = 42566;  // Use the port you assigned to the backend server, this would normally go in a .env file
const backendURL = `http://classwork.engr.oregonstate.edu:${backendPort}`;

function App() {
            const [rowToEdit, setRowToEdit] = useState([]);
    return (
        <>
            <h1>3Designs and Manufacturing Database Portal</h1>
            <Navigation />
            <Routes>
                <Route path="/" element={<Home backendURL={backendURL}/>} />
                <Route path="/customers" element={<Customers backendURL={backendURL} setRowToEdit={setRowToEdit}/>}/>
                <Route path="/colors" element={<Colors backendURL={backendURL} setRowToEdit={setRowToEdit}/>}/>\
                <Route path="/materialTypes" element={<MaterialTypes backendURL={backendURL} setRowToEdit={setRowToEdit}/>}/>
                <Route path="/parts" element={<Parts backendURL={backendURL} setRowToEdit={setRowToEdit}/>}/>
                <Route path="/orders" element={<Orders backendURL={backendURL} setRowToEdit={setRowToEdit}/>}/>
                <Route path="/machines" element={<Machines backendURL={backendURL} setRowToEdit={setRowToEdit}/>}/>
                <Route path="/editcustomers" element={<EditCustomers backendURL={backendURL} rowToEdit={rowToEdit}/>}/>
                <Route path="/editcolors" element={<EditColors backendURL={backendURL} rowToEdit={rowToEdit}/>}/>
                <Route path="/editmaterialTypes" element={<EditMaterialTypes backendURL={backendURL} rowToEdit={rowToEdit}/>}/>
                <Route path="/editParts" element={<EditParts backendURL={backendURL} rowToEdit={rowToEdit}/>}/>
                <Route path="/editOrders" element={<EditOrders backendURL={backendURL} rowToEdit={rowToEdit}/>}/>
                <Route path="/editMachines" element={<EditMachines backendURL={backendURL} rowToEdit={rowToEdit}/>}/>
                <Route path="/editMaterials" element={<EditMaterials backendURL={backendURL} rowToEdit={rowToEdit}/>}/>
                <Route path="/editPartMachine" element={<EditPartMachine backendURL={backendURL} rowToEdit={rowToEdit}/>}/>
                <Route path="/editPartMaterial" element={<EditPartMaterials backendURL={backendURL} rowToEdit={rowToEdit}/>}/>
            </Routes>
        </>
    );

} export default App;

//acquired from https://canvas.oregonstate.edu/courses/2042369/pages/exploration-web-application-technology-2?module_item_id=26640188