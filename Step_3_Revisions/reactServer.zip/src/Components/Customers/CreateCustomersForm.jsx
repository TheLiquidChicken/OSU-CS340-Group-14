import {useState} from 'react';
import React from 'react';
    function CreateCustomerForm ({}) {
        const createCustomer = async () => {
            console.log('Edit Customer Executed')
        //connect to backend and edit here
        }
        
        const [email, setEmail] = useState();
        const [phoneNumber, setPhoneNumber] = useState();
        const [primaryContact, setPrimaryContact] = useState();
        const [totalOrders, setTotalOrders] = useState();
        const [totalSpent, setTotalSpent] = useState();
        const [address, setAddress] = useState();
        const [mostUsedColor, setMostUsedColor] = useState();
        const [mostUsedMaterialType, setMostUsedMaterialType] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Customer</legend>
            <label>Enter email
                <input type="text" className="unit-input" value={email}
                    onChange={e => setEmail(e.target.value)} />
            </label>
            <br/>
            <label>Enter phoneNumber
                <input type="text" className="unit-input" value={phoneNumber}
                    onChange={e => setPhoneNumber(e.target.value)} />
            </label>
            <br/>
            <label>Enter primaryContact
                <input type="text" className="unit-input" value={primaryContact}
                    onChange={e => setPrimaryContact(e.target.value)} />
            </label>
            <br/>
            <label>Enter totalOrders
                <input type="number" className="unit-input" value={totalOrders}
                    onChange={e => setTotalOrders(e.target.value)} />
            </label>
            <br/>
            <label>Enter totalSpent
                <input type="number" className="unit-input" value={totalSpent}
                    onChange={e => setTotalSpent(e.target.value)} />
            </label>
            <br/>
            <label>Enter address
                <input type="text" className="unit-input" value={address}
                    onChange={e => setAddress(e.target.value)} />
            </label>
            <br/>
            <label>Enter mostUsedColor
                <input type="text" className="unit-input" value={mostUsedColor}
                    onChange={e => setMostUsedColor(e.target.value)} />
            </label>
            <br/>
            <label>Enter mostUsedMaterialType
                <input type="text" className="unit-input" value={mostUsedColor}
                    onChange={e => setMostUsedMaterialType(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            createCustomer();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default CreateCustomerForm;