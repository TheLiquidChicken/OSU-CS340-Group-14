import {useState} from 'react';
import React from 'react';
    function editCustomerForm ({rowToEdit}) {
        const editCustomer = async () => {
            console.log('Edit Customer Executed')
        //connect to backend and edit here
        }
        
        const [email, setEmail] = useState(rowToEdit.email);
        const [phoneNumber, setPhoneNumber] = useState(rowToEdit.phoneNumber);
        const [primaryContact, setPrimaryContact] = useState(rowToEdit.primaryContact);
        const [totalOrders, setTotalOrders] = useState(rowToEdit.totalOrders);
        const [totalSpent, setTotalSpent] = useState(rowToEdit.totalSpent);
        const [address, setAddress] = useState(rowToEdit.address);
        const [mostUsedColor, setMostUsedColor] = useState(rowToEdit.mostUsedColor);
        const [mostUsedMaterialType, setMostUsedMaterialType] = useState(rowToEdit.mostUsedMaterialType);

        return (
            <div>
                <h3>Customer ID is {rowToEdit.customerID}</h3>
                <form>
                    <fieldset>
                        <legend>Edit Customer</legend>
            <label>Enter email
                <input type="text" className="unit-input" value={email}
                    onChange={e => setEmail(e.target.value)} />
            </label>
            <br/>
            <label>Enter phoneNumber
                <input type="text" className="unit-input" value={phoneNumber}
                    onChange={e => setPhoneNumber(e.target.value)} />
            </label>
            <br/>
            <label>Enter primaryContact
                <input type="text" className="unit-input" value={primaryContact}
                    onChange={e => setPrimaryContact(e.target.value)} />
            </label>
            <br/>
            <label>Enter totalOrders
                <input type="number" className="unit-input" value={totalOrders}
                    onChange={e => setTotalOrders(e.target.value)} />
            </label>
            <br/>
            <label>Enter totalSpent
                <input type="number" className="unit-input" value={totalSpent}
                    onChange={e => setTotalSpent(e.target.value)} />
            </label>
            <br/>
            <label>Enter address
                <input type="text" className="unit-input" value={address}
                    onChange={e => setAddress(e.target.value)} />
            </label>
            <br/>
            <label>Enter mostUsedColor
                <input type="text" className="unit-input" value={mostUsedColor}
                    onChange={e => setMostUsedColor(e.target.value)} />
            </label>
            <br/>
            <label>Enter mostUsedMaterialType
                <input type="text" className="unit-input" value={mostUsedColor}
                    onChange={e => setMostUsedMaterialType(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            editCustomer();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default editCustomerForm;