import React from "react";
import Options from "./CustomersOptions.jsx";
import CustomersOptions from "./CustomersOptions.jsx";
function CustomersRow({setRowToEdit, customer, customerID, email, phoneNumber, primaryContact, totalOrders, totalSpent, address, mostUsedColor, mostUsedMaterialType}) {

    return(
        <tr>
            <td>
                {customerID}
            </td>
            <td>
                {email}
            </td>
            <td>
                {phoneNumber}
            </td>
            <td>
                {primaryContact}
            </td>
            <td>
                {totalOrders}
            </td>
            <td>
                {totalSpent}
            </td>
            <td>
                {address}
            </td>
            <td>
                {mostUsedColor}
            </td>
            <td>
                {mostUsedMaterialType}
            </td>
            <td>
                <CustomersOptions customer={customer} setRowToEdit={setRowToEdit}/>
            </td>
            
        </tr>
    )
}
export default CustomersRow;