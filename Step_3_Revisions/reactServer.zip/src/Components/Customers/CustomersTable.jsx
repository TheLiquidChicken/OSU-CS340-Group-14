import React from "react";
import CustomersRow from "./CustomersRow"
import Customers from "../../Pages/View/Customers";
function CustomersTable({customers, setRowToEdit}){

    return (
        <table>
            <thead>
                <tr>
                    <th>
                        customerID
                    </th>
                    <th>
                        email
                    </th>
                    <th>
                        phoneNumber
                    </th>
                    <th>
                        primaryContact
                    </th>
                    <th>
                        totalOrders
                    </th>
                    <th>
                        totalSpent
                    </th>
                    <th>
                        address
                    </th>
                    <th>
                        mostUsedColor
                    </th>
                    <th>
                        mostUsedMaterialType
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {customers.map(customer => <CustomersRow customer = {customer}
                                                         setRowToEdit = {setRowToEdit}
                                                         customerID = {customer.customerID}
                                                         email = {customer.email}
                                                         phoneNumber = {customer.phoneNumber}
                                                         primaryContact = {customer.primaryContact}
                                                         totalOrders = {customer.totalOrders}
                                                         totalSpent = {customer.totalSpent}
                                                         address = {customer.address}
                                                         mostUsedColor = {customer.mostUsedColor}
                                                         mostUsedMaterialType={customer.mostUsedMaterialType}

                /> )}
            </tbody>
        </table>
    )
}
export default CustomersTable;