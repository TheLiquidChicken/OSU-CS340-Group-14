import React from "react";
import PartsRow from "./PartsRow"
import Parts from "../../Pages/View/Parts";
function PartsTable({parts, setRowToEdit}){

    return (
        <table>
            <thead>
                <tr>
                    <th>
                        partID
                    </th>
                    <th>
                        partName
                    </th>
                    <th>
                        partPath
                    </th>
                    <th>
                        quantity
                    </th>
                    <th>
                        mass
                    </th>
                    <th>
                        infillDensity
                    </th>
                    <th>
                        orderID
                    </th>
                    <th>
                        options
                    </th>
                </tr>
            </thead>
            <tbody>
                {parts.map(part => <PartsRow part = {part}
                                                         setRowToEdit = {setRowToEdit}
                                                         part = {part}
                                                         partID = {part.partID}
                                                         partName = {part.partName}
                                                         partPath = {part.partPath}
                                                         quantity = {part.quantity}
                                                         mass = {part.mass}
                                                         infillDensity = {part.infillDensity}
                                                         orders_orderID = {part.orders_orderID}

                /> )}
            </tbody>
        </table>
    )
}
export default PartsTable;