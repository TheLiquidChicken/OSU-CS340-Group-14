import {useState} from 'react';
import React from 'react';
    function editPartForm ({rowToEdit}) {
        const editForm = async () => {
            console.log('Edit Part Executed')
        //connect to backend and edit here
        }
        
        const [partID, setPartID] = useState(rowToEdit.partID);
        const [partName, setPartName] = useState(rowToEdit.partName);
        const [partPath, setPartPath] = useState(rowToEdit.partPath);
        const [quantity, setQuantity] = useState(rowToEdit.quantity);
        const [mass, setMass] = useState(rowToEdit.mass);
        const [infillDensity, setInfillDensity] = useState(rowToEdit.infillDensity);
        const [orders_orderID, setOrders_orderID] = useState(rowToEdit.orders_orderID);
        const [mostUsedMaterialType, setMostUsedMaterialType] = useState(rowToEdit.mostUsedMaterialType);

        return (
            <div>
                <h3>Part ID is {rowToEdit.partID}</h3>
                <form>
                    <fieldset>
                        <legend>Edit Part</legend>
            <br/>
            <label>Enter partName
                <input type="text" className="unit-input" value={partName}
                    onChange={e => setPartName(e.target.value)} />
            </label>
            <br/>
            <label>Enter partPath
                <input type="text" className="unit-input" value={partPath}
                    onChange={e => setPartPath(e.target.value)} />
            </label>
            <br/>
            <label>Enter quantity
                <input type="number" className="unit-input" value={quantity}
                    onChange={e => setQuantity(e.target.value)} />
            </label>
            <br/>
            <label>Enter mass
                <input type="number" className="unit-input" value={mass}
                    onChange={e => setMass(e.target.value)} />
            </label>
            <br/>
            <label>Enter infillDensity
                <input type="text" className="unit-input" value={infillDensity}
                    onChange={e => setInfillDensity(e.target.value)} />
            </label>
            <br/>
            <label>Enter orders_orderID
                <input type="text" className="unit-input" value={orders_orderID}
                    onChange={e => setOrders_orderID(e.target.value)} />
            </label>
            <br/>
                    </fieldset>
                    <button onClick={e => {
            editForm();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default editPartForm;