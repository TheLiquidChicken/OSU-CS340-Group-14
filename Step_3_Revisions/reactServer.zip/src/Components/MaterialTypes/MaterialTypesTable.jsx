import React from "react";
import MaterialTypesRow from "./MaterialTypesRow"
import MaterialTypes from "../../Pages/View/MaterialTypes";
function MaterialTypesTable({materialTypes, setRowToEdit}){

    return (
        <table>
            <thead>
                <tr>
                    <th>
                        MaterialTypeID
                    </th>
                    <th>
                        MaterialTypeDescription
                    </th>
                </tr>
            </thead>
            <tbody>
                {materialTypes.map(materialType => <MaterialTypesRow 
                    materialType = {materialType}
                    materialTypeID = {materialType.materialTypeID}
                    materialTypeDescription = {materialType.materialTypeDescription}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
    )
}
export default MaterialTypesTable;