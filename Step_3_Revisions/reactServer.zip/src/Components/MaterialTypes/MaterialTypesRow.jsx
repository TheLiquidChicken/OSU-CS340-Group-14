import React from "react";
import MaterialTypesOptions from "./MaterialTypesOptions.jsx";
function MaterialTypesRow({materialType, materialTypeID, materialTypeDescription, setRowToEdit}) {
    return(
        <tr>
            <td>
                {materialTypeID}
            </td>
            <td>
                {materialTypeDescription}
            </td>
            <td>
                <MaterialTypesOptions materialType={materialType} setRowToEdit={setRowToEdit}/>
            </td>
            
        </tr>
    )
}
export default MaterialTypesRow;