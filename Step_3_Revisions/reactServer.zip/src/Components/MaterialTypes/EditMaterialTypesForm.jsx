import {useState} from 'react';
import React from 'react';
    function editMaterialTypeForm ({rowToEdit}) {
        const editMaterialType = async () => {
        //connect to backend and edit here
        }
        
        const [materialTypeID, setMaterialTypeID] = useState(rowToEdit.materialTypeID);
        const [materialTypeDescription, setMaterialTypeDescription] = useState(rowToEdit.materialTypeDescription);

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Edit MaterialType</legend>
            <label>Enter MaterialTypeID
                <input type="text" className="unit-input" value={materialTypeID}
                    onChange={e => setMaterialTypeID(e.target.value)} />
            </label>
            <br/>
            <label>Enter MaterialTypeDescription
                <input type="text" className="unit-input" value={materialTypeDescription}
                    onChange={e => setMaterialTypeDescription(e.target.value)} />
            </label>
                    </fieldset>
                </form>
            </div>
        )
    }



export default editMaterialTypeForm;