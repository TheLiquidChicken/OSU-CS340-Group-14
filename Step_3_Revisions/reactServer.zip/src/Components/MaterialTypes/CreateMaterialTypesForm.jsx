import {useState} from 'react';
import React from 'react';
    function createMaterialTypeForm ({}) {
        const editMaterialType = async () => {
        //connect to backend and edit here
        }
        
        const [materialTypeID, setMaterialTypeID] = useState();
        const [materialTypeDescription, setMaterialTypeDescription] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create MaterialType</legend>
            <label>Enter MaterialTypeID
                <input type="text" className="unit-input" value={materialTypeID}
                    onChange={e => setMaterialTypeID(e.target.value)} />
            </label>
            <br/>
            <label>Enter MaterialTypeDescription
                <input type="text" className="unit-input" value={materialTypeDescription}
                    onChange={e => setMaterialTypeDescription(e.target.value)} />
            </label>
                    </fieldset>
                </form>
            </div>
        )
    }



export default createMaterialTypeForm;