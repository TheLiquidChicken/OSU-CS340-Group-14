import {useState} from 'react';
import React from 'react';
    function createMachineForm ({}) {
        const createMachine = async () => {
            console.log('Edit Machine Executed')
        //connect to backend and edit here
        }
        
        const [machineDescription, setMachineDescription] = useState();
        const [lastServiceDate, setLastServiceDate] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Order</legend>
            <label>Enter machineDescription
                <input type="text" className="unit-input" value={machineDescription}
                    onChange={e => setRevenue(e.target.value)} />
            </label>
            <br/>
            <label>Enter lastServiceDate
                <input type="date" className="unit-input" value={lastServiceDate}
                    onChange={e => setLastServiceDate(e.target.value)} />
            </label>
            <br/>
                    </fieldset>
                    <button onClick={e => {
            createMachine();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default createMachineForm;