import React from "react";
import MachinesRow from "./MachinesRow.jsx"
import Machines from "../../Pages/View/Machines.jsx";
function MachinesTable({machines, setRowToEdit}){

    return (
        <table>
            <thead>
                <tr>
                    <th>
                        machineID
                    </th>
                    <th>
                        machineDescription
                    </th>
                    <th>
                        lastServiceDate
                    </th>
                    <th>
                        options
                    </th>
                </tr>
            </thead>
            <tbody>
                {machines.map(machine => <MachinesRow 
                    machine = {machine}
                    machineID = {machine.machineID}
                    machineDescription = {machine.machineDescription}
                    lastServiceDate = {machine.lastServiceDate}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
    )
}
export default MachinesTable;