import React from "react";
import MachineOptions from "./MachineOptions.jsx";
function MachinesRow({machine, machineID, machineDescription, lastServiceDate, setRowToEdit}) {

    return(
        <tr>
            <td>
                {machineID}
            </td>
            <td>
                {machineDescription}
            </td>
            <td>
                {lastServiceDate}
            </td>
            <td>
                <MachineOptions machine={machine} setRowToEdit={setRowToEdit}/>
            </td>
            
        </tr>
    )
}
export default MachinesRow;