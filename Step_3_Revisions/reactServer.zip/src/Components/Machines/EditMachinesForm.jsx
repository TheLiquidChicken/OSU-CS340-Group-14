import {useState} from 'react';
import React from 'react';
    function editMachineForm ({rowToEdit}) {
        const editMachine = async () => {
            console.log('Edit Machine Executed')
        //connect to backend and edit here
        }
        
        const [machineDescription, setMachineDescription] = useState(rowToEdit.machineDescription);
        const [lastServiceDate, setLastServiceDate] = useState(rowToEdit.lastServiceDate);

        return (
            <div>
                <h3>Order ID is {rowToEdit.orderID}</h3>
                <form>
                    <fieldset>
                        <legend>Edit Order</legend>
            <label>Enter machineDescription
                <input type="text" className="unit-input" value={machineDescription}
                    onChange={e => setRevenue(e.target.value)} />
            </label>
            <br/>
            <label>Enter lastServiceDate
                <input type="date" className="unit-input" value={lastServiceDate}
                    onChange={e => setLastServiceDate(e.target.value)} />
            </label>
            <br/>
                    </fieldset>
                    <button onClick={e => {
            editMachine();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default editMachineForm;