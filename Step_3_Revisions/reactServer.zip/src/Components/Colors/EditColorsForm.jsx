import {useState} from 'react';
import React from 'react';
    function editColorForm ({rowToEdit}) {
        const editColor = async () => {
        //connect to backend and edit here
        console.log('edit color executed')
        }
        
        const [colorID, setColorID] = useState(rowToEdit.colorID);
        const [colorDescription, setColorDescritpion] = useState(rowToEdit.colorDescription);

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Edit Color</legend>
            <label>Enter ColorID
                <input type="text" className="unit-input" value={colorID}
                    onChange={e => setColorID(e.target.value)} />
            </label>
            <br/>
            <label>Enter phoneNumber
                <input type="text" className="unit-input" value={colorDescription}
                    onChange={e => setColorDescritpion(e.target.value)} />
            </label>
                    </fieldset>
                </form>
            <button onClick={e => {
            editColor();
            e.preventDefault();
        }}>Submit</button>
            </div>
        )
    }



export default editColorForm;