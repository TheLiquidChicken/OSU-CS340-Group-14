import React from "react";
import ColorsOptions from "./ColorsOptions.jsx";
function ColorsRow({color, colorID, colorDescription, setRowToEdit}) {

    return(
        <tr>
            <td>
                {colorID}
            </td>
            <td>
                {colorDescription}
            </td>
            <td>
                <ColorsOptions color={color} setRowToEdit={setRowToEdit}/>
            </td>
            
        </tr>
    )
}
export default ColorsRow;