import React from "react";
import ColorsRow from "./ColorsRow"
import Colors from "../../Pages/View/Colors";
function ColorsTable({colors, setRowToEdit}){

    return (
        <table>
            <thead>
                <tr>
                    <th>
                        ColorID
                    </th>
                    <th>
                        ColorDescription
                    </th>
                </tr>
            </thead>
            <tbody>
                {colors.map(color => <ColorsRow 
                    color = {color}
                    colorID = {color.colorID}
                    colorDescription = {color.colorDescription}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
    )
}
export default ColorsTable;