import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function ColorsOptions({color, setRowToEdit}){
    const deleteColor = async () => {
        console.log('DeleteColor Called! Nothing Here Yet!');
    }

    const editColor = async (colorToEdit)=> {
        setRowToEdit(colorToEdit);
    }
    return(
        <div>
            <FaTrash id="Modify" onClick={deleteColor}/> 

            <Link to="/editcolors"><CiEdit id="Modify" onClick={() => editColor(color)}/></Link>
        </div>
    )
}
export default ColorsOptions;