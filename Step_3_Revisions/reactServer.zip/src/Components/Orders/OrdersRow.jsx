import React from "react";
import OrdersOptions from "./OrdersOptions.jsx";
function OrdersRow({order, orderID, revenue, date, customers_customerID, setRowToEdit}) {
    return(
        <tr>
            <td>
                {orderID}
            </td>
            <td>
                {revenue}
            </td>
            <td>
                {date}
            </td>
            <td>
                {customers_customerID}
            </td>
            <td>
                <OrdersOptions order={order} setRowToEdit={setRowToEdit}/>
            </td>
            
        </tr>
    )
}
export default OrdersRow;