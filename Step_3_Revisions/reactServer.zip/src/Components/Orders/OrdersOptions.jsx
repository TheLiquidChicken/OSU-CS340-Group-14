import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function OrderOptions({order, setRowToEdit}){
    const deleteOrders = async () => {
        console.log('DeleteOrders Called! Nothing Here Yet!');
    }

    const editOrders = async (orders) => {
        setRowToEdit(orders);
    }
    return(
        <div>
            <FaTrash id="Modify" onClick={deleteOrders}/> 

            <Link to="/editorders"><CiEdit id="Modify" onClick={() => editOrders(order)}/></Link>
        </div>
    )
}
export default OrderOptions;