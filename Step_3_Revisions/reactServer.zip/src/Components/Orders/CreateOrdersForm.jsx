import {useState} from 'react';
import React from 'react';
    function createOrderForm ({}) {
        const createOrder = async () => {
            console.log('Create Order Executed')
        //connect to backend and edit here
        }
        
        const [revenue, setRevenue] = useState();
        const [date, setDate] = useState();
        const [customers_customerID, setCustomers_customerID] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Order</legend>
            <label>Enter revenue
                <input type="number" className="unit-input" value={revenue}
                    onChange={e => setRevenue(e.target.value)} />
            </label>
            <br/>
            <label>Enter date
                <input type="date" className="unit-input" value={date}
                    onChange={e => setDate(e.target.value)} />
            </label>
            <br/>
            <label>Enter customers_customerID
                <input type="text" className="unit-input" value={customers_customerID}
                    onChange={e => setCustomers_customerID(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            createOrder();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default createOrderForm;