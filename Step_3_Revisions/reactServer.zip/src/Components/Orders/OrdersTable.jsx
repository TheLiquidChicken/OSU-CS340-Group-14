import React from "react";
import OrdersRow from "./OrdersRow"
function OrdersTable({orders, setRowToEdit}){

    return (
        <table>
            <thead>
                <tr>
                    <th>
                        orderID
                    </th>
                    <th>
                        revenue
                    </th>
                    <th>
                        date
                    </th>
                    <th>
                        customerID
                    </th>
                    <th>
                        options
                    </th>
                </tr>
            </thead>
            <tbody>
                {orders.map(order => <OrdersRow 
                    setRowToEdit = {setRowToEdit}
                    order = {order}
                    orderID = {order.orderID}
                    revenue = {order.revenue}
                    date = {order.date}
                    customers_customerID = {order.customers_customerID}
                /> )}
            </tbody>
        </table>
    )
}
export default OrdersTable;