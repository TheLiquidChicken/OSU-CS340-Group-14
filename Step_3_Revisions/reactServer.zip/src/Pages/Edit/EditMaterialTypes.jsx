import { useEffect } from "react";
import React from "react";
import EditMaterialTypesForm from "../../Components/MaterialTypes/EditMaterialTypesForm";


function EditMaterialTypes({rowToEdit}){
    return (
        <>
            <h2>This is the Edit Color Page.</h2>
            <p>Edit a color below.</p>
            <EditMaterialTypesForm rowToEdit={rowToEdit}/>
            
        </>
    )
}

export default EditMaterialTypes;