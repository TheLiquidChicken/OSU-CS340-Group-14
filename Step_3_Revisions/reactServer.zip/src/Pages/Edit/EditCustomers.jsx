import { useEffect } from "react";
import React from "react";
import EditCustomersForm from "../../Components/Customers/EditCustomersForm";


function EditCustomers({rowToEdit}){
    return (
        <>
            <h2>This is the Edit Customer Page.</h2>
            <p>Edit a customer below.</p>
            <EditCustomersForm rowToEdit={rowToEdit}/>
            
        </>
    )
}

export default EditCustomers;