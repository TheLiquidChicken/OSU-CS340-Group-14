import { useEffect } from "react";
import React from "react";
import EditMachinesForm from "../../Components/Machines/EditMachinesForm";


function EditMachines({rowToEdit}){
    return (
        <>
            <h2>This is the Edit Machine Page.</h2>
            <p>Edit a machine below.</p>
            <EditMachinesForm rowToEdit={rowToEdit}/>
            
        </>
    )
}

export default EditMachines;