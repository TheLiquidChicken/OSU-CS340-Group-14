import React from "react";
function Home() {
    return (
        <>
            <h1>3Designs and Manufacturing Database Portal</h1>
            <div className="homepageDescription">
                <p>Add, remove, and update customers, materials, colors, and orders here!</p>
            </div>
        </>
    )
} export default Home;
//acquired from https://canvas.oregonstate.edu/courses/2042369/pages/exploration-web-application-technology-2?module_item_id=26640188