import React from "react";
import ColorsTable from '/src/Components/Colors/ColorsTable'
import CreateColorsForm from "../../Components/Colors/CreateColorsForm";
import { useEffect, useState} from "react";
function Colors({setRowToEdit}) {
    const [colors, setColors] = useState([]);
    useEffect(() => {
        const colorTest = [{colorID:"PLYMKR-RED", colorDescription:"RED"}]
        setColors(colorTest);
    }, []
)
    //const loadColors = async () => {
        //const response = await fetch('/customers');
        //const data = await response.json();
        //setCustomers = (data);
    //}
    return (
        <>
            <h1>3Designs Colors</h1>
            <div className="homepageDescription">
                <p>Add, remove, and update colors here!</p>
            </div>
            <ColorsTable colors={colors} setRowToEdit={setRowToEdit}/>
            <br/>
            <CreateColorsForm/>
        </>
    )
} export default Colors;