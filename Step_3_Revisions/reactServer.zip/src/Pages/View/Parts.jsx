import React from "react";
import CustomersTable from '/src/Components/Parts/PartsTable';
import CreatePartsForm from "../../Components/Parts/CreatePartsForm";
import { useEffect, useState} from "react";
function Customers({setRowToEdit}) {
    const [parts, setParts] = useState([]);
    useEffect(() => {
        const partTest = [{partID:1, partName:"test.stl", partPath:"parts/test.stl", quantity:5, mass:3, infillDensity:30, orders_orderID:1}]
        setParts(partTest);
    }, []
)
    //const loadCustomers = async () => {
        //const response = await fetch('/customers');
        //const data = await response.json();
        //setCustomers = (data);
    //}
    return (
        <>
            <h1>3Designs Parts</h1>
            <div className="homepageDescription">
                <p>Add, remove, and update parts here!</p>
            </div>
            <CustomersTable parts={parts} setRowToEdit={setRowToEdit}/>
            <br/>
            <CreatePartsForm/>
        </>
    )
} export default Customers;