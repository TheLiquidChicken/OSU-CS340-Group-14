import React from "react";
import OrdersTable from '/src/Components/Orders/OrdersTable';
import CreateOrderForm from "../../Components/Orders/CreateOrdersForm";
import { useEffect, useState} from "react";
function Orders({setRowToEdit}) {
    const [orders, setOrders] = useState([]);
    useEffect(() => {
        const orderTest = [{orderID:1, revenue:3, date:"2026-05-08", customers_customerID:1}]
        setOrders(orderTest);
    }, []
)
    //const loadCustomers = async () => {
        //const response = await fetch('/customers');
        //const data = await response.json();
        //setCustomers = (data);
    //}
    return (
        <>
            <h1>3Designs Orders</h1>
            <div className="homepageDescription">
                <p>Add, remove, and update orders here!</p>
            </div>
            <OrdersTable orders={orders} setRowToEdit={setRowToEdit}/>
            <br/>
            <CreateOrderForm/>
        </>
    )
} export default Orders;