import React from "react";
import MaterialTypesTable from "../../Components/MaterialTypes/MaterialTypesTable";
import CreateMaterialTypeForm from "../../Components/MaterialTypes/CreateMaterialTypesForm";
import { useEffect, useState} from "react";
function MaterialTypes({setRowToEdit}) {
    const [materialTypes, setMaterialTypes] = useState([]);
    useEffect(() => {
        const materialTypeTest = [{materialTypeID:"PLYMKR-PETG", materialTypeDescription:"PETG"}];
        setMaterialTypes(materialTypeTest);
    }, []
)
    //const loadColors = async () => {
        //const response = await fetch('/customers');
        //const data = await response.json();
        //setCustomers = (data);
    //}
    return (
        <>
            <h1>3Designs MaterialTypes</h1>
            <div className="homepageDescription">
                <p>Add, remove, and update material types here!</p>
            </div>
            <MaterialTypesTable materialTypes={materialTypes} setRowToEdit={setRowToEdit}/>
            <br/>
            <CreateMaterialTypeForm/>
        </>
    )
} export default MaterialTypes;