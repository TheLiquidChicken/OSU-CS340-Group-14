import React from "react";
import MachinesTable from '/src/Components/Machines/MachinesTable.jsx'
import CreateMachineForm from "../../Components/Machines/CreateMachinesForm";
import { useEffect, useState} from "react";
function Machines({setRowToEdit}) {
    const [machines, setMachines] = useState([]);
    useEffect(() => {
        const machineTest = [{machineID:1, machineDescription:"UM3", lastServiceDate:"2026-05-08"}];
        setMachines(machineTest);
    }, []
)
    //const loadColors = async () => {
        //const response = await fetch('/customers');
        //const data = await response.json();
        //setCustomers = (data);
    //}
    return (
        <>
            <h1>3Designs Machines</h1>
            <div className="homepageDescription">
                <p>Add, remove, and update machines here!</p>
            </div>
            <MachinesTable machines={machines} setRowToEdit={setRowToEdit}/>
            <br/>
            <CreateMachineForm/>
        </>
    )
} export default Machines;