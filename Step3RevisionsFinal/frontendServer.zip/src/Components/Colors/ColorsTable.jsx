import React from "react";
import ColorsRow from "./ColorsRow"
import Colors from "../../Pages/View/Colors";
function ColorsTable({colors, setRowToEdit}){

    return (
        <table>
            <thead>
                <tr>
                    <th>
                        Color ID
                    </th>
                    <th>
                        Color Description
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {colors.map(color => <ColorsRow 
                    color = {color}
                    colorID = {color.colorID}
                    colorDescription = {color.colorDescription}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
    )
}
export default ColorsTable;