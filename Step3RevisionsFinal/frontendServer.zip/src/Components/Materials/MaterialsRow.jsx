import React from "react";
import MaterialsOptions from "./MaterialsOptions.jsx";
function MaterialsRow({material, materialID, materialTypeID, colorID, setRowToEdit}) {
    return(
        <tr>
            <td>
                {materialID}
            </td>
            <td>
                {materialTypeID}
            </td>
            <td>
                {colorID}
            </td>
            <td>
                <MaterialsOptions material={material} setRowToEdit={setRowToEdit}/>
            </td>
            
        </tr>
    )
}
export default MaterialsRow;