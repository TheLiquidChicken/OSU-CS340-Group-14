import React from "react";
import MaterialsRow from "./MaterialsRow"
import { useState, useEffect } from "react";
function MaterialsTable({setRowToEdit}){
    const [materials, setMaterials] = useState([]);
        useEffect(() => {
            const materialTest = [{materialID:1, materialTypeID:"PLYMKR-PETG", colorID:"PLYMKR-RED"}];
            setMaterials(materialTest);
        }, []
    )
    return (
        <table>
            <thead>
                <tr>
                    <th>
                        Material ID
                    </th>
                    <th>
                        Material Type ID
                    </th>
                    <th>
                        Color ID
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {materials.map(material => <MaterialsRow 
                    material = {material}
                    materialID = {material.materialID}
                    materialTypeID = {material.materialTypeID}
                    colorID = {material.colorID}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
    )
}
export default MaterialsTable;