import {useState} from 'react';
import React from 'react';
    function editMaterialsForm ({rowToEdit}) {
        const editMaterial = async () => {
        //connect to backend and edit here
        }
        
        const [materialID, setMaterialID] = useState(rowToEdit.materialID);
        const [materialTypeID, setMaterialTypeID] = useState(rowToEdit.materialTypeID);
        const [colorID, setColorID] = useState(rowToEdit.colorID);

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Edit Materials with ID: {materialID}</legend>
            <label>Enter Material Type ID
                <input type="text" className="unit-input" value={materialTypeID}
                    onChange={e => setMaterialTypeID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Color ID
                <input type="text" className="unit-input" value={colorID}
                    onChange={e => setColorID(e.target.value)} />
            </label>
                    </fieldset>
                </form>
                <button onClick={e => {
            editMaterial();
            e.preventDefault();
        }}>Submit</button>
            </div>
        )
    }



export default editMaterialsForm;