import {useState} from 'react';
import React from 'react';
    function createMaterialsForm ({}) {
        const createMaterial = async () => {
        //connect to backend and edit here
        }
        const [materialTypeID, setMaterialTypeID] = useState();
        const [colorID, setColorID] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Material</legend>
            <label>Enter Material Type ID
                <input type="text" className="unit-input" value={materialTypeID}
                    onChange={e => setMaterialTypeID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Material Color
                <input type="text" className="unit-input" value={colorID}
                    onChange={e => setColorID(e.target.value)} />
            </label>
                    </fieldset>
                </form>
                <button onClick={e => {
            createMaterial();
            e.preventDefault();
        }}>Submit</button>
            </div>
        )
    }



export default createMaterialsForm;