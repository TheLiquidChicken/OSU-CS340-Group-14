import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function MaterialOptions({material, setRowToEdit}){
    const deleteMaterial = async () => {
        console.log('DeleteMaterialTypes Called! Nothing Here Yet!');
    }

    const editMaterial = async (materialTypes) => {
        setRowToEdit(materialTypes);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deleteMaterial}/> 

            <Link to="/editMaterials"><CiEdit class="modify" onClick={() => editMaterial(material)}/></Link>
        </div>
    )
}
export default MaterialOptions;