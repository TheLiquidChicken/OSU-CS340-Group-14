import React from "react";
import PartMachinesRow from "./PartMachinesRow"
import { useState, useEffect } from "react";
function PartMachinesTable({setRowToEdit}){
    const [partMachines, setPartMaterials] = useState([]);
        useEffect(() => {
            const partMachineTest = [{partMachineID:1, machineID:1, partID:1}];
            setPartMaterials(partMachineTest);
        }, []
    )
    return (
        <table>
            <thead>
                <tr>
                    <th>
                        PartMachineID
                    </th>
                    <th>
                        MachineID
                    </th>
                    <th>
                        PartID
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {partMachines.map(partMachine => <PartMachinesRow 
                    partMachine = {partMachine}
                    partMachineID = {partMachine.partMachineID}
                    machineID = {partMachine.machineID}
                    partID = {partMachine.partID}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
    )
}
export default PartMachinesTable;