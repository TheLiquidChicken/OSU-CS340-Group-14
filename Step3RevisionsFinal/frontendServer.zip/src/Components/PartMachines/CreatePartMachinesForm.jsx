import {useState} from 'react';
import React from 'react';
    function createPartMachinesForm ({}) {
        const createPartMachine = async () => {
        //connect to backend and edit here
        }
        
        const [machineID, setMachineID] = useState();
        const [partID, setPartID] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create PartMaterial</legend>
            <label>Enter MachineID
                <input type="text" className="unit-input" value={machineID}
                    onChange={e => setMachineID(e.target.value)} />
            </label>
            <br/>
            <label>Enter PartID
                <input type="text" className="unit-input" value={partID}
                    onChange={e => setPartID(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            createPartMachine();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default createPartMachinesForm;