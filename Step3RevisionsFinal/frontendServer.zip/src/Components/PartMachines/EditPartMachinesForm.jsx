import {useState} from 'react';
import React from 'react';
    function EditPartMachinesForm ({rowToEdit}) {
        const editPartMachine = async () => {
        //connect to backend and edit here
        }
        
        const [partMachineID, setPartMachineID] = useState(rowToEdit.partMachineID);
        const [machineID, setMachineID] = useState(rowToEdit.machineID);
        const [partID, setPartID] = useState(rowToEdit.partID);

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Edit PartMachine of PartMachine ID: {partMachineID}</legend>
            <label>Enter MachineID
                <input type="text" className="unit-input" value={machineID}
                    onChange={e => setMachineID(e.target.value)} />
            </label>
            <br/>
            <label>Enter PartID
                <input type="text" className="unit-input" value={partID}
                    onChange={e => setPartID(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            editPartMachine();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default EditPartMachinesForm;