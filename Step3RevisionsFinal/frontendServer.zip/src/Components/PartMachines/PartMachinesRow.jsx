import React from "react";
import PartMachineOptions from "./PartMachinesOptions.jsx";
function PartMachineRow({partMachine, partMachineID, machineID, partID, setRowToEdit}) {
    return(
        <tr>
            <td>
                {partMachineID}
            </td>
            <td>
                {machineID}
            </td>
            <td>
                {partID}
            </td>
            <td>
                <PartMachineOptions partMachine={partMachine} setRowToEdit={setRowToEdit}/>
            </td>
            
        </tr>
    )
}
export default PartMachineRow;