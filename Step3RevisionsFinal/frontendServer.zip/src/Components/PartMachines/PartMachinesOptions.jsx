import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function PartMachinesOptions({partMachine, setRowToEdit}){
    const deletePartMachine = async () => {
        console.log('deletePartMachine Called! Nothing Here Yet!');
    }

    const editPartMachine = async (materialTypes) => {
        setRowToEdit(materialTypes);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deletePartMachine}/> 

            <Link to="/editPartMachine"><CiEdit class="modify" onClick={() => editPartMachine(partMachine)}/></Link>
        </div>
    )
}
export default PartMachinesOptions;