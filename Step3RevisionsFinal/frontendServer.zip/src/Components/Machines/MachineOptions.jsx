import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function MachineOptions({machine, setRowToEdit}){
    const deleteMachines = async () => {
        console.log('DeleteMachines Called! Nothing Here Yet!');
    }

    const editMachines = async (machines) => {
        setRowToEdit(machines);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deleteMachines}/> 

            <Link to="/editmachines"><CiEdit class="modify" onClick={() => editMachines(machine)}/></Link>
        </div>
    )
}
export default MachineOptions;