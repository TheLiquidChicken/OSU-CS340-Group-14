import {useState} from 'react';
import React from 'react';
    function createMaterialTypeForm ({}) {
        const createMaterialType = async () => {
        //connect to backend and edit here
        }
        
        const [materialTypeID, setMaterialTypeID] = useState();
        const [materialTypeDescription, setMaterialTypeDescription] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Material Type</legend>
            <label>Enter Material Type ID
                <input type="text" className="unit-input" value={materialTypeID}
                    onChange={e => setMaterialTypeID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Material Type Description
                <input type="text" className="unit-input" value={materialTypeDescription}
                    onChange={e => setMaterialTypeDescription(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            createMaterialType();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default createMaterialTypeForm;