import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function MaterialTypeOptions({materialType, setRowToEdit}){
    const deleteMaterialTypes = async () => {
        console.log('DeleteMaterialTypes Called! Nothing Here Yet!');
    }

    const editMaterialTypes = async (materialTypes) => {
        setRowToEdit(materialTypes);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deleteMaterialTypes}/> 

            <Link to="/editmaterialTypes"><CiEdit class="modify" onClick={() => editMaterialTypes(materialType)}/></Link>
        </div>
    )
}
export default MaterialTypeOptions;