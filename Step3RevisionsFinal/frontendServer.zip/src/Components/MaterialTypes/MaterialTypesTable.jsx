import React from "react";
import MaterialTypesRow from "./MaterialTypesRow"
import MaterialTypes from "../../Pages/View/MaterialTypes";
function MaterialTypesTable({materialTypes, setRowToEdit}){

    return (
        <table>
            <thead>
                <tr>
                    <th>
                        Material Type ID
                    </th>
                    <th>
                        Material Type Description
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {materialTypes.map(materialType => <MaterialTypesRow 
                    materialType = {materialType}
                    materialTypeID = {materialType.materialTypeID}
                    materialTypeDescription = {materialType.materialTypeDescription}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
    )
}
export default MaterialTypesTable;