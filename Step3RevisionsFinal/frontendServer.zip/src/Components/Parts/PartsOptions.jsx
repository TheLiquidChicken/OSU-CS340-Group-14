import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function PartsOptions({part, setRowToEdit}){
    const deletePart = async () => {
        console.log('DeletePart Called! Nothing Here Yet!');
    }

    const editPart = async (customerToEdit)=> {
        setRowToEdit(customerToEdit);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deletePart}/> 

            <Link to="/editparts"><CiEdit class="modify" onClick={() => editPart(part)}/></Link>
        </div>
    )
}
export default PartsOptions;