import {useState} from 'react';
import React from 'react';
    function createPartsForm ({}) {
        const createPart = async () => {
            console.log('Edit Part Executed')
        //connect to backend and edit here
        }
        
        const [partID, setPartID] = useState();
        const [partName, setPartName] = useState();
        const [partPath, setPartPath] = useState();
        const [quantity, setQuantity] = useState();
        const [mass, setMass] = useState();
        const [infillDensity, setInfillDensity] = useState();
        const [orders_orderID, setOrders_orderID] = useState();
        const [mostUsedMaterialType, setMostUsedMaterialType] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Edit Part</legend>
            <br/>
            <label>Enter Part Name
                <input type="text" className="unit-input" value={partName}
                    onChange={e => setPartName(e.target.value)} />
            </label>
            <br/>
            <label>Enter Part File Path
                <input type="text" className="unit-input" value={partPath}
                    onChange={e => setPartPath(e.target.value)} />
            </label>
            <br/>
            <label>Enter Quantity
                <input type="number" className="unit-input" value={quantity}
                    onChange={e => setQuantity(e.target.value)} />
            </label>
            <br/>
            <label>Enter Part Mass
                <input type="number" className="unit-input" value={mass}
                    onChange={e => setMass(e.target.value)} />
            </label>
            <br/>
            <label>Enter Part Infill Density
                <input type="text" className="unit-input" value={infillDensity}
                    onChange={e => setInfillDensity(e.target.value)} />
            </label>
            <br/>
            <label>Enter Order ID
                <input type="text" className="unit-input" value={orders_orderID}
                    onChange={e => setOrders_orderID(e.target.value)} />
            </label>
            <br/>
                    </fieldset>
                    <button onClick={e => {
            createPart();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default createPartsForm;