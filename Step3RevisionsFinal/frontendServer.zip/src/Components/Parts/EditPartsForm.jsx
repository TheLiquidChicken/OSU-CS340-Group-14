import {useState} from 'react';
import React from 'react';
    function editPartForm ({rowToEdit}) {
        const editPart = async () => {
            console.log('Edit Part Executed')
        //connect to backend and edit here
        }
        
        const [partID, setPartID] = useState(rowToEdit.partID);
        const [partName, setPartName] = useState(rowToEdit.partName);
        const [partPath, setPartPath] = useState(rowToEdit.partPath);
        const [quantity, setQuantity] = useState(rowToEdit.quantity);
        const [mass, setMass] = useState(rowToEdit.mass);
        const [infillDensity, setInfillDensity] = useState(rowToEdit.infillDensity);
        const [orders_orderID, setOrders_orderID] = useState(rowToEdit.orders_orderID);
        const [mostUsedMaterialType, setMostUsedMaterialType] = useState(rowToEdit.mostUsedMaterialType);

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Edit Part with ID: {partID}</legend>
            <br/>
            <label>Enter Part Name
                <input type="text" className="unit-input" value={partName}
                    onChange={e => setPartName(e.target.value)} />
            </label>
            <br/>
            <label>Enter Part File Path
                <input type="text" className="unit-input" value={partPath}
                    onChange={e => setPartPath(e.target.value)} />
            </label>
            <br/>
            <label>Enter Quantity
                <input type="number" className="unit-input" value={quantity}
                    onChange={e => setQuantity(e.target.value)} />
            </label>
            <br/>
            <label>Enter Part Mass
                <input type="number" className="unit-input" value={mass}
                    onChange={e => setMass(e.target.value)} />
            </label>
            <br/>
            <label>Enter Infill Density
                <input type="text" className="unit-input" value={infillDensity}
                    onChange={e => setInfillDensity(e.target.value)} />
            </label>
            <br/>
            <label>Enter Order ID
                <input type="text" className="unit-input" value={orders_orderID}
                    onChange={e => setOrders_orderID(e.target.value)} />
            </label>
            <br/>
                    </fieldset>
                    <button onClick={e => {
            editPart();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default editPartForm;