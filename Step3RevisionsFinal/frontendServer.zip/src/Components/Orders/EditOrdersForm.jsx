import {useState} from 'react';
import React from 'react';
    function editOrderForm ({rowToEdit}) {
        const editOrder = async () => {
            console.log('Edit Order Executed')
        //connect to backend and edit here
        }
        
        const [revenue, setRevenue] = useState(rowToEdit.revenue);
        const [date, setDate] = useState(rowToEdit.date);
        const [customers_customerID, setCustomers_customerID] = useState(rowToEdit.customers_customerID);

        return (
            <div>
                <h3>Order ID is {rowToEdit.orderID}</h3>
                <form>
                    <fieldset>
                        <legend>Edit Order</legend>
            <label>Enter Revenue
                <input type="number" className="unit-input" value={revenue}
                    onChange={e => setRevenue(e.target.value)} />
            </label>
            <br/>
            <label>Enter Date
                <input type="date" className="unit-input" value={date}
                    onChange={e => setDate(e.target.value)} />
            </label>
            <br/>
            <label>Enter CustomerID
                <input type="text" className="unit-input" value={customers_customerID}
                    onChange={e => setCustomers_customerID(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            editOrder();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default editOrderForm;