import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function PartMaterialsOptions({partMaterial, setRowToEdit}){
    const deletePartMaterial = async () => {
        console.log('deletePartMaterial Called! Nothing Here Yet!');
    }

    const editPartMaterial = async (materialTypes) => {
        setRowToEdit(materialTypes);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deletePartMaterial}/> 

            <Link to="/editPartMaterial"><CiEdit class="modify" onClick={() => editPartMaterial(partMaterial)}/></Link>
        </div>
    )
}
export default PartMaterialsOptions;