import {useState} from 'react';
import React from 'react';
    function CreatePartMaterialsForm ({}) {
        const createPartMaterial = async () => {
        //connect to backend and edit here
        }
        
        const [materialID, setMaterialID] = useState();
        const [partID, setPartID] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Part Material</legend>
            <label>Enter Material ID
                <input type="text" className="unit-input" value={materialID}
                    onChange={e => setMaterialID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Part ID
                <input type="text" className="unit-input" value={partID}
                    onChange={e => setPartID(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            createPartMaterial();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default CreatePartMaterialsForm;