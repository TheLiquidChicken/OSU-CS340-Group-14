import {useState} from 'react';
import React from 'react';
    function EditPartMaterialsForm ({rowToEdit}) {
        const editPartMaterial = async () => {
        //connect to backend and edit here
        }
        
        const [partMaterialID, setPartMaterialID] = useState(rowToEdit.partMaterialID);
        const [materialID, setMaterialID] = useState(rowToEdit.materialID);
        const [partID, setPartID] = useState(rowToEdit.partID);

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Edit Part Material With ID: {partMaterialID}</legend>
            <label>Enter Material ID
                <input type="text" className="unit-input" value={materialID}
                    onChange={e => setMaterialID(e.target.value)} />
            </label>
            <br/>
            <label>Enter Part ID
                <input type="text" className="unit-input" value={partID}
                    onChange={e => setPartID(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            editPartMaterial();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default EditPartMaterialsForm;