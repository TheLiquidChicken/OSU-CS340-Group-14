import React from "react";
import PartMaterialsOptions from "./PartMaterialsOptions.jsx";
function PartMaterialRow({partMaterial, partMaterialID, materialID, partID, setRowToEdit}) {
    return(
        <tr>
            <td>
                {partMaterialID}
            </td>
            <td>
                {materialID}
            </td>
            <td>
                {partID}
            </td>
            <td>
                <PartMaterialsOptions partMaterial={partMaterial} setRowToEdit={setRowToEdit}/>
            </td>
            
        </tr>
    )
}
export default PartMaterialRow;