import React from "react";
import PartMaterialsRow from "./PartMaterialsRow"
import { useState, useEffect } from "react";
function PartMaterialsTable({setRowToEdit}){
    const [partMachines, setPartMaterials] = useState([]);
        useEffect(() => {
            const partMachineTest = [{partMaterialID:1, materialID:1, partID:1}];
            setPartMaterials(partMachineTest);
        }, []
    )
    return (
        <table>
            <thead>
                <tr>
                    <th>
                        Part Material ID
                    </th>
                    <th>
                        Material ID
                    </th>
                    <th>
                        Part ID
                    </th>
                    <th>
                        Options
                    </th>
                </tr>
            </thead>
            <tbody>
                {partMachines.map(partMaterial => <PartMaterialsRow 
                    partMaterial = {partMaterial}
                    partMaterialID = {partMaterial.partMaterialID}
                    materialID = {partMaterial.materialID}
                    partID = {partMaterial.partID}
                    setRowToEdit = {setRowToEdit}
                /> )}
            </tbody>
        </table>
    )
}
export default PartMaterialsTable;