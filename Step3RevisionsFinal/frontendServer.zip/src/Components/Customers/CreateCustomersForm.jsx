import {useState} from 'react';
import React from 'react';
    function CreateCustomerForm ({}) {
        const createCustomer = async () => {
            console.log('Edit Customer Executed')
        //connect to backend and edit here
        }
        
        const [email, setEmail] = useState();
        const [phoneNumber, setPhoneNumber] = useState();
        const [primaryContact, setPrimaryContact] = useState();
        const [address, setAddress] = useState();

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Create Customer</legend>
            <label>Enter Email
                <input type="text" className="unit-input" value={email}
                    onChange={e => setEmail(e.target.value)} />
            </label>
            <br/>
            <label>Enter Phone Number
                <input type="text" className="unit-input" value={phoneNumber}
                    onChange={e => setPhoneNumber(e.target.value)} />
            </label>
            <br/>
            <label>Enter Primary Contact
                <input type="text" className="unit-input" value={primaryContact}
                    onChange={e => setPrimaryContact(e.target.value)} />
            </label>
            <br/>
            <label>Enter Address
                <input type="text" className="unit-input" value={address}
                    onChange={e => setAddress(e.target.value)} />
            </label>
                    </fieldset>
                    <button onClick={e => {
            createCustomer();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default CreateCustomerForm;