import { FaTrash } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import React from "react";
import { Link } from "react-router-dom";
function CustomersOptions({customer, setRowToEdit}){
    const deleteCustomer = async () => {
        console.log('DeleteCustomer Called! Nothing Here Yet!');
    }

    const editCustomer = async (customerToEdit)=> {
        setRowToEdit(customerToEdit);
    }
    return(
        <div class="options">
            <FaTrash class="modify" onClick={deleteCustomer}/> 

            <Link to="/editcustomers"><CiEdit class="modify" onClick={() => editCustomer(customer)}/></Link>
        </div>
    )
}
export default CustomersOptions;