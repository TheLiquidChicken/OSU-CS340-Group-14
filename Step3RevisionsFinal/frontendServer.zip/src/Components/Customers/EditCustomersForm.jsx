import {useState} from 'react';
import React from 'react';
    function editCustomerForm ({rowToEdit}) {
        const editCustomer = async () => {
            console.log('Edit Customer Executed')
        //connect to backend and edit here
        }
        
        const [email, setEmail] = useState(rowToEdit.email);
        const [phoneNumber, setPhoneNumber] = useState(rowToEdit.phoneNumber);
        const [primaryContact, setPrimaryContact] = useState(rowToEdit.primaryContact);
        const [address, setAddress] = useState(rowToEdit.address);

        return (
            <div>
                <form>
                    <fieldset>
                        <legend>Edit Customer with ID: {rowToEdit.customerID}</legend>
            <label>Enter Email
                <input type="text" className="unit-input" value={email}
                    onChange={e => setEmail(e.target.value)} />
            </label>
            <br/>
            <label>Enter Phone Number
                <input type="text" className="unit-input" value={phoneNumber}
                    onChange={e => setPhoneNumber(e.target.value)} />
            </label>
            <br/>
            <label>Enter Primary Contact
                <input type="text" className="unit-input" value={primaryContact}
                    onChange={e => setPrimaryContact(e.target.value)} />
            </label>
            <br/>
            <br/>
            <label>Enter Address
                <input type="text" className="unit-input" value={address}
                    onChange={e => setAddress(e.target.value)} />
            </label>
            <br/>
                    </fieldset>
                    <button onClick={e => {
            editCustomer();
            e.preventDefault();
        }}>Submit</button>
                </form>
            </div>
        )
    }



export default editCustomerForm;