import React from "react";
import ColorsTable from '/src/Components/Colors/ColorsTable'
import CreateColorsForm from "../../Components/Colors/CreateColorsForm";
import MaterialsTable from "../../Components/Materials/MaterialsTable";
import CreateMaterialsForm from "../../Components/Materials/CreateMaterialsForm";
import PartMaterialsTable from "../../Components/PartMaterials/PartMaterialsTable"
import CreatePartMaterialsForm from "../../Components/PartMaterials/CreatePartMaterialsForm";
import { useEffect, useState} from "react";
function Colors({setRowToEdit}) {
    const [colors, setColors] = useState([]);
    useEffect(() => {
        const colorTest = [{colorID:"PLYMKR-RED", colorDescription:"RED"}]
        setColors(colorTest);
    }, []
)
    //const loadColors = async () => {
        //const response = await fetch('/customers');
        //const data = await response.json();
        //setCustomers = (data);
    //}
    return (
        <>
            <h2>3Designs Colors</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update colors here!</p>
            </div>
            <div class="entityCategory">
                <ColorsTable colors={colors} setRowToEdit={setRowToEdit}/>
                <br/>
                <CreateColorsForm/>
            </div>
            <h3>Materials Combinations</h3>
            <p>Add types of materials and color combinations here</p>
            <div class="entityCategory">
                <MaterialsTable setRowToEdit={setRowToEdit}/>
                <br/>
                <CreateMaterialsForm/>
            </div>
            <h3>Part Material Combinations</h3>
            <p>Assign Materials to parts here</p>
            <div class="entityCategory">
                <PartMaterialsTable setRowToEdit={setRowToEdit}/>
                <br/>
                <CreatePartMaterialsForm/>
            </div>
        </>
    )
} export default Colors;