import React from "react";
import PartsTable from '/src/Components/Parts/PartsTable';
import CreatePartsForm from "../../Components/Parts/CreatePartsForm";
import { useEffect, useState} from "react";
import PartMachinesTable from "../../Components/PartMachines/PartMachinesTable";
import CreatePartMachinesForm from "../../Components/PartMachines/CreatePartMachinesForm";
import PartMaterialsTable from "../../Components/PartMaterials/PartMaterialsTable";
import CreatePartMaterialsForm from "../../Components/PartMaterials/CreatePartMaterialsForm";
function Customers({setRowToEdit}) {
    const [parts, setParts] = useState([]);
    useEffect(() => {
        const partTest = [{partID:1, partName:"test.stl", partPath:"parts/test.stl", quantity:5, mass:3, infillDensity:30, orders_orderID:1}]
        setParts(partTest);
    }, []
)
    //const loadCustomers = async () => {
        //const response = await fetch('/customers');
        //const data = await response.json();
        //setCustomers = (data);
    //}
    return (
        <>
            <h2>3Designs Parts</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update parts here!</p>
            </div>
            <div class="entityCategory">
                <PartsTable parts={parts} setRowToEdit={setRowToEdit}/>
                <br/>
                <CreatePartsForm/>
            </div>

            <h3>Part Machine Assignments</h3>
            <p>Assign Parts to Machines here</p>
            <div class="entityCategory">
                <PartMachinesTable setRowToEdit={setRowToEdit}/>
                <br/>
                <CreatePartMachinesForm/>
            </div>

            <h3>Part Material Combinations</h3>
            <p>Assign Materials to parts here</p>
            <div class="entityCategory">
                <PartMaterialsTable setRowToEdit={setRowToEdit}/>
                <br/>
                <CreatePartMaterialsForm/>
            </div>
        </>
    )
} export default Customers;