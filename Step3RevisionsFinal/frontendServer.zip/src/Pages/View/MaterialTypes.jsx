import React from "react";
import MaterialTypesTable from "../../Components/MaterialTypes/MaterialTypesTable";
import CreateMaterialTypeForm from "../../Components/MaterialTypes/CreateMaterialTypesForm";
import MaterialsTable from "../../Components/Materials/MaterialsTable";
import CreateMaterialsForm from "../../Components/Materials/CreateMaterialsForm";
import PartMaterialsTable from "../../Components/PartMaterials/PartMaterialsTable";
import CreatePartMaterialsForm from "../../Components/PartMachines/CreatePartMachinesForm";
import { useEffect, useState} from "react";
function MaterialTypes({setRowToEdit}) {
    const [materialTypes, setMaterialTypes] = useState([]);
    useEffect(() => {
        const materialTypeTest = [{materialTypeID:"PLYMKR-PETG", materialTypeDescription:"PETG"}];
        setMaterialTypes(materialTypeTest);
    }, []
)
    //const loadColors = async () => {
        //const response = await fetch('/customers');
        //const data = await response.json();
        //setCustomers = (data);
    //}
    return (
        <>
            <h2>3Designs MaterialTypes</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update material types here!</p>
            </div>
            <div class="entityCategory">
                <MaterialTypesTable materialTypes={materialTypes} setRowToEdit={setRowToEdit}/>
                <br/>
                <CreateMaterialTypeForm/>
            </div>

            <h3>Materials Combinations</h3>
            <p>Add types of materials and color combinations here</p>
            <div class="entityCategory">
                <MaterialsTable setRowToEdit={setRowToEdit}/>
                <br/>
                <CreateMaterialsForm/>
            </div>

            <h3>Part Material Combinations</h3>
            <p>Assign Materials to parts here</p>
            <div class="entityCategory">
                <PartMaterialsTable setRowToEdit={setRowToEdit}/>
                <br/>
                <CreatePartMaterialsForm/>
            </div>
        </>
    )
} export default MaterialTypes;