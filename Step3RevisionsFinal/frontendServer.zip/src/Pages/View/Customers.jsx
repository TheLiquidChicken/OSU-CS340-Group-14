import React from "react";
import CustomersTable from '/src/Components/Customers/CustomersTable'
import CreateCustomersForm from "../../Components/Customers/CreateCustomersForm";
import { useEffect, useState} from "react";
function Customers({setRowToEdit}) {
    const [customers, setCustomers] = useState([]);
    useEffect(() => {
        const customerTest = [{customerID:1, email:"test.mail", phoneNumber:"1234567890", primaryContact:"Bill", address:"somewhere"}]
        setCustomers(customerTest);
    }, []
)
    //const loadCustomers = async () => {
        //const response = await fetch('/customers');
        //const data = await response.json();
        //setCustomers = (data);
    //}
    return (
        <>
            <h2>3Designs Customers</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update customers here!</p>
            </div>
            <CustomersTable customers={customers} setRowToEdit={setRowToEdit}/>
            <br/>
            <CreateCustomersForm/>
        </>
    )
} export default Customers;