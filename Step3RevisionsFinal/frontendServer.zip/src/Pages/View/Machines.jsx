import React from "react";
import MachinesTable from '/src/Components/Machines/MachinesTable.jsx'
import CreateMachineForm from "../../Components/Machines/CreateMachinesForm";
import { useEffect, useState} from "react";

import CreatePartMachinesForm from "../../Components/PartMachines/CreatePartMachinesForm";
import PartMachinesTable from "../../Components/PartMachines/PartMachinesTable";
function Machines({setRowToEdit}) {
    const [machines, setMachines] = useState([]);
    useEffect(() => {
        const machineTest = [{machineID:1, machineDescription:"UM3", lastServiceDate:"2026-05-08"}];
        setMachines(machineTest);
    }, []
)
    //const loadColors = async () => {
        //const response = await fetch('/customers');
        //const data = await response.json();
        //setCustomers = (data);
    //}
    return (
        <>
            <h2>3Designs Machines</h2>
            <div className="homepageDescription">
                <p>Add, remove, and update machines here!</p>
            </div>
            <div class="entityCategory">
                <MachinesTable machines={machines} setRowToEdit={setRowToEdit}/>
                <br/>
                <CreateMachineForm/>
            </div>
            <h3>Part Machine Assignments</h3>
            <p>Assign Parts to Machines here</p>
            <div class="entityCategory">
                <PartMachinesTable setRowToEdit={setRowToEdit}/>
                <br/>
                <CreatePartMachinesForm/>
            </div>
        </>
    )
} export default Machines;