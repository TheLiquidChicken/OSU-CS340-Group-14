import { useEffect } from "react";
import React from "react";
import EditPartMachinesForm from "../../Components/PartMachines/EditPartMachinesForm";


function EditPartMachine({rowToEdit}){
    return (
        <>
            <h2>This is the Edit Material Page.</h2>
            <p>Edit a material below.</p>
            <EditPartMachinesForm rowToEdit={rowToEdit}/>
            
        </>
    )
}

export default EditPartMachine;