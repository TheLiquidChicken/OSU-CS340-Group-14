import { useEffect } from "react";
import React from "react";
import EditMachinesForm from "../../Components/Machines/EditMachinesForm";


function EditMachines({rowToEdit}){
    return (
        <>
            <h2>Edit Machines</h2>
            <p>Edit a machine below.</p>
            <EditMachinesForm rowToEdit={rowToEdit}/>
            
        </>
    )
}

export default EditMachines;