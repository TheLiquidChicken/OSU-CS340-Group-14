import { useEffect } from "react";
import React from "react";
import EditColorsForm from "../../Components/Colors/EditColorsForm";


function EditColors({rowToEdit}){
    return (
        <>
            <h2>Edit Color</h2>
            <p>Edit a color below.</p>
            <EditColorsForm rowToEdit={rowToEdit}/>
            
        </>
    )
}

export default EditColors;