import { useEffect } from "react";
import React from "react";
import EditPartMaterialsForm from "../../Components/PartMaterials/EditPartMaterialsForm";


function EditPartMaterials({rowToEdit}){
    return (
        <>
            <h2>This is the Edit Part Material Page.</h2>
            <p>Edit a PartMaterial below.</p>
            <EditPartMaterialsForm rowToEdit={rowToEdit}/>
            
        </>
    )
}

export default EditPartMaterials;